"""Точка входа: окно + трей, одна копия приложения, режим «окно пароля» для sudo (--askpass)."""

import os
import sys

from . import VERSION, APP_NAME, APP_ID

USAGE = f"""{APP_NAME} {VERSION} — приложение для рабочего стола (by MaxFoley · сделано с помощью Grok Bot)

  adguard-vpn-desktop              открыть окно (если уже запущено — показать его)
  adguard-vpn-desktop --minimized  запустить свёрнутым в трей
  adguard-vpn-desktop --quit       закрыть запущенное приложение
  adguard-vpn-desktop --version    версия и найденная библиотека Qt
"""


def askpass(argv) -> int:
    """sudo просит пароль: показываем поле ввода, печатаем пароль в stdout (так работает SUDO_ASKPASS)."""
    from .qt_compat import QtWidgets, E, qexec
    from .ui import STYLE, shield_icon, GREEN
    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication(sys.argv[:1])
    app.setStyleSheet(STYLE)
    prompt = " ".join(a for a in argv if a != "--askpass").strip()
    dlg = QtWidgets.QInputDialog()
    dlg.setWindowTitle(f"{APP_NAME} — пароль администратора")
    dlg.setWindowIcon(shield_icon(GREEN))
    dlg.setLabelText("AdGuard VPN нужны права администратора, чтобы включить или выключить VPN.\n"
                     "Введите пароль вашего пользователя Linux.\n\n"
                     "Чтобы не спрашивал каждый раз — запустите установщик ещё раз\n"
                     "и согласитесь на «правило sudo без пароля»."
                     + (f"\n\n{prompt}" if prompt else ""))
    dlg.setTextEchoMode(E(QtWidgets.QLineEdit, "EchoMode.Password"))
    dlg.setOkButtonText("OK")
    dlg.setCancelButtonText("Отмена")
    dlg.resize(460, 200)
    if qexec(dlg) and dlg.textValue():
        sys.stdout.write(dlg.textValue() + "\n")
        sys.stdout.flush()
        return 0
    return 1


def main(argv=None) -> int:
    argv = list(sys.argv if argv is None else argv)
    args = argv[1:]
    if "-h" in args or "--help" in args:
        print(USAGE)
        return 0
    if "--askpass" in args:
        return askpass(args)
    try:
        from .qt_compat import QtCore, QtWidgets, QtNetwork, API, qexec
    except ImportError as e:
        print(f"{APP_NAME}: не найдена библиотека Qt для Python.\n{e}\n\n"
              "Запустите установщик ещё раз: bash install-adguard-vpn-desktop.sh", file=sys.stderr)
        return 3
    if "--version" in args:
        print(f"{APP_NAME} {VERSION} (Qt: {API} {QtCore.qVersion()}, Python {sys.version.split()[0]})")
        return 0

    from . import core
    core.setup_logging()
    QtWidgets.QApplication.setApplicationName(APP_ID)
    QtWidgets.QApplication.setApplicationDisplayName(APP_NAME)
    if hasattr(QtWidgets.QApplication, "setDesktopFileName"):
        QtWidgets.QApplication.setDesktopFileName(APP_ID)
    app = QtWidgets.QApplication(argv[:1])
    app.setQuitOnLastWindowClosed(False)

    # одна копия: вторая просит первую показать окно (или выйти) и завершается
    server_name = f"{APP_ID}-{os.getuid()}"
    if QtNetwork is not None:
        sock = QtNetwork.QLocalSocket()
        sock.connectToServer(server_name)
        if sock.waitForConnected(500):
            msg = b"quit" if "--quit" in args else (b"noop" if "--minimized" in args else b"show")
            sock.write(msg)
            sock.flush()
            sock.waitForBytesWritten(500)
            sock.disconnectFromServer()
            return 0
        if "--quit" in args:
            return 0
        QtNetwork.QLocalServer.removeServer(server_name)
        server = QtNetwork.QLocalServer()
        server.listen(server_name)
    else:
        server = None

    from .ui import MainWindow, Bridge, STYLE
    app.setStyleSheet(STYLE)
    bridge = Bridge()
    backend = core.Backend(notify=lambda t, b: bridge.notify.emit(t, b))
    backend.events.listeners.append(lambda ev: bridge.event.emit(ev))
    win = MainWindow(backend, bridge)

    if server is not None:
        def on_conn():
            c = server.nextPendingConnection()
            if c is None:
                return

            def read():
                data = bytes(c.readAll())
                if b"quit" in data:
                    win.quit_app()
                elif b"show" in data:
                    win.show_window()
            c.readyRead.connect(read)
        server.newConnection.connect(on_conn)

    backend.events.add("info", f"Приложение {VERSION} запущено",
                       backend.who() + f"\nQt: {API} {QtCore.qVersion()}, Python {sys.version.split()[0]}")
    settings = core.load_settings()
    minimized = "--minimized" in args or settings.get("start_minimized")
    if minimized and win.tray is not None:
        win._retime()
    else:
        win.show()
    win.initial_load()
    backend.start_background()
    rc = qexec(app)
    backend.stop()
    return rc
