"""AdGuard VPN — приложение для рабочего стола Linux (Qt + значок в трее).

Автор: MaxFoley · сделано с помощью Grok Bot.
"""
VERSION = "1.0.0"
APP_ID = "adguard-vpn-desktop"
APP_NAME = "AdGuard VPN"
