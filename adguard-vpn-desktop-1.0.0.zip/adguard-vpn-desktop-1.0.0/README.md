# AdGuard VPN — desktop (Linux)

Неофициальное окно с треем для официального [AdGuard VPN CLI](https://github.com/AdguardTeam/AdGuardVPNCLI) на Linux: Bazzite, SteamOS (режим рабочего стола) и другие дистрибутивы. Версия 1.0.0.

![Подключено](screenshots/03-connected.png)

**Установка и использование:** [ИНСТРУКЦИЯ.md](ИНСТРУКЦИЯ.md)

## Что умеет

- Статус VPN, локация и внешний IP. Быстрые кнопки (самая быстрая, Словакия, Германия, Швеция, Казахстан) с пингом. Кнопка «⛔ Отключить» отменяет и зависшее подключение.
- ⭐ Избранное и поиск по всем локациям.
- Вход по QR-коду или ссылке, сведения о тарифе, выход из аккаунта.
- Автоподключение при запуске и переподключение при обрыве (3 попытки). Обновление CLI. Автозапуск свёрнутым в трей.
- Значок в трее меняет цвет по состоянию. В меню трея есть быстрые локации и избранное. Закрытое окно продолжает работать в трее.
- «📜 Журнал» с фильтром «только ошибки».

## Как устроено

- Python 3 + Qt (PySide6, PyQt6 или PyQt5). Если системного Qt нет, установщик ставит PySide6-Essentials в отдельный venv в `~/.local/share/adguard-vpn-desktop/venv` и ничего не меняет в системе, так что это работает и на системах только для чтения.
- Приложение работает от имени пользователя и вызывает `adguardvpn-cli` напрямую. Для `sudo` используется правило NOPASSWD из установщика, а без него — окно ввода пароля (`SUDO_ASKPASS`).
- Окно никогда не блокируется: CLI выполняется в фоне с жёсткими таймаутами и группами процессов.
- Совместная работа с плагином для игрового режима:
  - общий замок `$XDG_RUNTIME_DIR/adguard-vpn-cli.lock` (flock);
  - общая отметка «отключено вручную» `~/.local/state/adguard-vpn/desired.json`, которую уважают переподключение и автоподключение;
  - общие избранные: `~/homebrew/settings/adguard-vpn/favorites.json`, если он есть.

Файлы: настройки — `~/.config/adguard-vpn-desktop/`, журнал и состояние — `~/.local/state/adguard-vpn-desktop/`.

## Установщик

```
bash install-adguard-vpn-desktop.sh [--system=bazzite|steamos|other] [--yes]
                                    [--no-sudoers] [--no-autostart] [--dry-run] [--uninstall]
```

## Разработка

```
python3 -m adguard_vpn_desktop             # запуск из папки проекта
python3 tests/test_core.py                  # тесты логики (мок CLI, без Qt)
QT_QPA_PLATFORM=offscreen python3 tests/make_screenshots.py
```

Лицензия MIT (см. [LICENSE](LICENSE)). Не связано с AdGuard Software Ltd.

---
<sub>by MaxFoley · сделано с помощью Grok Bot</sub>
