# AdGuard VPN for Linux desktop (Bazzite, SteamOS, others)

You need an AdGuard VPN account and an internet connection.

## Install

1. Download `install-adguard-vpn-desktop.sh` and `adguard-vpn-desktop-1.1.0.zip` from Releases to your **Downloads** folder.
2. Open **Konsole** (terminal) and run:
   ```
   bash ~/Downloads/install-adguard-vpn-desktop.sh
   ```
3. Choose your system (Bazzite, SteamOS or other), enter your password (it stays invisible while you type), and answer **y** to every question.
4. Open **AdGuard VPN** from the desktop shortcut or the app menu. Log in with the QR code or the link in the window.

That's it. Click a country to connect, or «⛔ Отключить» to disconnect. The tray icon shows the VPN state, and the app keeps running in the tray when you close the window.

## If something is wrong

- The app warns you if setup isn't finished or you aren't logged in. Details are in «📜 Журнал» at the bottom of the window.
- Running the installer again (step 2) fixes almost everything.
- On SteamOS the `deck` user may have no password. Set one with `passwd`.
- To remove everything: `bash ~/Downloads/install-adguard-vpn-desktop.sh --uninstall`

There is also a separate plugin for Gaming Mode. The two work together: they share favourites and the manual "disconnected" state, and they don't get in each other's way.

> The app interface is in Russian.

---
<sub>by MaxFoley · made with Grok Bot</sub>
