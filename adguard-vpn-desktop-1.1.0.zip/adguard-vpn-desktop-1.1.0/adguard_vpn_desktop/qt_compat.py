"""
Qt без жёсткой привязки: PySide6 → PyQt6 → PyQt5 (что найдётся первым).
Порядок можно задать переменной ADGUARD_VPN_QT=PyQt5,PySide6 …
"""
import os

API = None
_errors = []
_order = [x.strip() for x in (os.environ.get("ADGUARD_VPN_QT") or "").split(",") if x.strip()]
for _name in _order + [n for n in ("PySide6", "PyQt6", "PyQt5") if n not in _order]:
    try:
        if _name == "PySide6":
            from PySide6 import QtCore, QtGui, QtWidgets          # noqa: F401
            try:
                from PySide6 import QtNetwork                       # noqa: F401
            except Exception:
                QtNetwork = None
            Signal = QtCore.Signal
        elif _name == "PyQt6":
            from PyQt6 import QtCore, QtGui, QtWidgets              # noqa: F401
            try:
                from PyQt6 import QtNetwork                         # noqa: F401
            except Exception:
                QtNetwork = None
            Signal = QtCore.pyqtSignal
        elif _name == "PyQt5":
            from PyQt5 import QtCore, QtGui, QtWidgets              # noqa: F401
            try:
                from PyQt5 import QtNetwork                         # noqa: F401
            except Exception:
                QtNetwork = None
            Signal = QtCore.pyqtSignal
        else:
            continue
        API = _name
        break
    except Exception as e:          # нет модуля или он сломан — пробуем следующий
        _errors.append(f"{_name}: {e}")

if API is None:
    raise ImportError("Не найден ни PySide6, ни PyQt6, ни PyQt5:\n  " + "\n  ".join(_errors))

Qt = QtCore.Qt


def E(owner, path: str):
    """Значение перечисления и в Qt6 (Qt.AlignmentFlag.AlignLeft), и в старом PyQt5 (Qt.AlignLeft)."""
    obj = owner
    try:
        for part in path.split("."):
            obj = getattr(obj, part)
        return obj
    except AttributeError:
        return getattr(owner, path.split(".")[-1])


def qexec(obj, *a):
    fn = getattr(obj, "exec", None) or getattr(obj, "exec_")
    return fn(*a)
