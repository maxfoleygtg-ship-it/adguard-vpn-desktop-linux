"""Окно и значок в трее. Всё долгое — в фоновых потоках (core.Backend), окно никогда не замирает."""

import os
import threading
import time
import webbrowser

from . import VERSION, APP_NAME
from . import core
from .core import (FIXED, FIXED_ISO, COUNTRY_RU, flag_of, label_of, target_of, loc_key, fixed_key, norm_city,
                   cities_of)
from .qt_compat import QtCore, QtGui, QtWidgets, Qt, Signal, E

POLL_MS = 4000             # статус, пока окно открыто
POLL_HIDDEN_MS = 15000     # статус для значка в трее, пока окно скрыто
LOC_REFRESH_MS = 60000     # пинг локаций
IP_REFRESH_MS = 60000
ACCOUNT_REFRESH_MS = 300000

GREEN, YELLOW, RED, GREY, BLUE = "#68bc71", "#ffc82c", "#ff6b6b", "#8a97ad", "#4da3ff"
GREEN_DARK = "#4caf50"
BG_TOP, BG_BOTTOM = "#05070d", "#0b1a33"
CARD, CARD_HOVER, CARD_BORDER = "#0f1d36", "#16294a", "#1c2f52"

ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
ICONS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "icons")
# картинки героя: можно заменить своими (mascot_<состояние>.png или .jpg, лучше квадрат ~512px)
MASCOT_NAMES = {"connected": "mascot_connected", "disconnected": "mascot_disconnected"}

STYLE = """
QWidget { background: transparent; color: #e3e8f0; font-size: 10.5pt; }
QMainWindow, QDialog, QMessageBox, QInputDialog { background: #08101f; }
#root { background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 %(top)s, stop:1 %(bottom)s); }
QScrollArea, #content, #page { background: transparent; border: none; }
QScrollArea > QWidget > QWidget { background: transparent; }
#card { background: %(card)s; border: 1px solid %(border)s; border-radius: 14px; }
QWidget#row { background: transparent; }
QLabel { background: transparent; }
QLabel#sectionTitle { color: %(grey)s; font-weight: bold; font-size: 8.5pt; letter-spacing: 1px; padding: 2px 6px; }
QLabel#title { font-size: 13pt; font-weight: bold; color: #ffffff; }
QLabel#pageTitle { font-size: 15pt; font-weight: bold; color: #ffffff; padding: 2px 4px; }
QLabel#bigState { font-size: 19pt; font-weight: bold; color: #ffffff; }
QLabel#bigState[state="on"] { color: %(green)s; }
QLabel#bigState[state="busy"] { color: %(yellow)s; }
QLabel#bigState[state="err"] { color: %(red)s; }
QLabel#subState { color: #c9d2e0; font-size: 11pt; }
QLabel#muted { color: %(grey)s; font-size: 9pt; }
QLabel#footer { color: #3d4f6e; font-size: 8pt; }
QLabel#key { color: %(grey)s; }
QLabel#warnText { color: %(yellow)s; font-size: 9pt; }
QLabel#errText { color: %(red)s; font-size: 9pt; }
QPushButton { background: #15284a; border: 1px solid #1f3760; border-radius: 10px; padding: 9px 14px; color: #e8eef7; }
QPushButton:hover { background: #1d3561; border-color: #2c4c84; }
QPushButton:pressed { background: #10203c; }
QPushButton:disabled { background: #0d1830; color: #4d5d78; border-color: #142441; }
QPushButton#loc { background: %(card)s; border: 1px solid %(border)s; border-radius: 12px; padding: 0; text-align: left; }
QPushButton#loc:hover { background: %(cardh)s; border-color: #2a4677; }
QPushButton#loc:disabled { background: #0b1629; }
QPushButton#loc[active="true"] { background: #10301f; border: 1px solid %(green)s; }
QPushButton#selector { background: %(card)s; border: 1px solid %(border)s; border-radius: 14px; padding: 0; }
QPushButton#selector:hover { background: %(cardh)s; border-color: %(green)s; }
QPushButton#danger { background: #3a1820; border: 1px solid #5a2430; color: #ffd6dc; }
QPushButton#danger:hover { background: #52212d; border-color: %(red)s; }
QPushButton#primary { background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 %(green)s, stop:1 %(greend)s);
    border: none; color: #ffffff; font-weight: bold; font-size: 11pt; border-radius: 12px; }
QPushButton#primary:hover { background: #7bcc83; }
QPushButton#primary:disabled { background: #2b4a33; color: #9fb6a4; }
QPushButton#star { background: transparent; border: none; padding: 4px; font-size: 15pt; min-width: 34px; max-width: 34px; color: #5d6f8f; }
QPushButton#star:hover { color: %(yellow)s; }
QPushButton#star[fav="true"] { color: %(yellow)s; }
QPushButton#link { background: transparent; border: none; color: %(grey)s; padding: 4px 6px; text-align: left; }
QPushButton#link:hover { color: #e3e8f0; }
#navbar { background: #060c18; border-top: 1px solid #14254a; }
QPushButton#nav { background: transparent; border: none; border-radius: 10px; padding: 6px 2px; color: #6f7f9c; font-size: 8.5pt; }
QPushButton#nav:hover { background: #0f1d36; color: #c9d2e0; }
QPushButton#nav:checked { color: %(green)s; background: #0d2219; font-weight: bold; }
QLineEdit, QComboBox, QPlainTextEdit, QListWidget {
    background: #0a1529; border: 1px solid %(border)s; border-radius: 10px; padding: 7px; color: #e8eef7;
    selection-background-color: %(greend)s; }
QLineEdit:focus, QComboBox:focus { border-color: %(green)s; }
QLineEdit#search { padding: 9px 12px; font-size: 10.5pt; border-radius: 12px; }
QComboBox QAbstractItemView { background: #0f1d36; selection-background-color: %(greend)s; border: 1px solid %(border)s; }
QListWidget::item { padding: 5px 3px; border-bottom: 1px solid #14254a; }
QListWidget::item:selected { background: #17305a; }
QCheckBox { spacing: 10px; background: transparent; padding: 3px 0; }
QCheckBox::indicator { width: 20px; height: 20px; border-radius: 6px; border: 1px solid #2a4066; background: #0a1529; }
QCheckBox::indicator:hover { border-color: %(green)s; }
QCheckBox::indicator:checked { background: %(green)s; border-color: %(green)s; }
QScrollBar:vertical { background: transparent; width: 8px; margin: 2px; }
QScrollBar::handle:vertical { background: #1c3156; border-radius: 4px; min-height: 30px; }
QScrollBar::handle:vertical:hover { background: #2a4677; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: transparent; }
QToolTip { background: #0f1d36; color: #e8eef7; border: 1px solid #2a4677; }
QMenu { background: #0b1629; border: 1px solid %(border)s; padding: 4px; }
QMenu::item { padding: 6px 22px 6px 14px; border-radius: 6px; }
QMenu::item:selected { background: #17305a; }
QMenu::item:disabled { color: %(grey)s; }
QMenu::separator { height: 1px; background: #1c2f52; margin: 4px 8px; }
""" % {"top": BG_TOP, "bottom": BG_BOTTOM, "card": CARD, "cardh": CARD_HOVER, "border": CARD_BORDER,
       "grey": GREY, "green": GREEN, "greend": GREEN_DARK, "yellow": YELLOW, "red": RED}


def ping_color(ms) -> str:
    if ms is None:
        return GREY
    return GREEN if ms < 80 else YELLOW if ms < 150 else RED


def ping_html(ms, frozen=False) -> str:
    if ms is None:
        return f"<span style='color:{GREY}'>—</span>"
    return f"<span style='color:{ping_color(ms)}'>{'📌 ' if frozen else ''}{ms} мс</span>"


def shield_icon(color: str, mark: str = "check") -> QtGui.QIcon:
    """Значок-щит, нарисованный кодом (не нужен модуль SVG): зелёный/жёлтый/серый/красный."""
    icon = QtGui.QIcon()
    for size in (16, 22, 24, 32, 48, 64, 128, 256):
        pm = QtGui.QPixmap(size, size)
        pm.fill(QtGui.QColor(0, 0, 0, 0))
        p = QtGui.QPainter(pm)
        p.setRenderHint(E(QtGui.QPainter, "RenderHint.Antialiasing"))
        s = size / 64.0
        path = QtGui.QPainterPath()
        path.moveTo(32 * s, 3 * s)
        path.lineTo(56 * s, 12 * s)
        path.cubicTo(56 * s, 36 * s, 48 * s, 52 * s, 32 * s, 61 * s)
        path.cubicTo(16 * s, 52 * s, 8 * s, 36 * s, 8 * s, 12 * s)
        path.closeSubpath()
        p.setPen(E(Qt, "PenStyle.NoPen"))
        p.setBrush(QtGui.QColor(color))
        p.drawPath(path)
        pen = QtGui.QPen(QtGui.QColor("#ffffff"))
        pen.setWidthF(max(1.5, 6 * s))
        pen.setCapStyle(E(Qt, "PenCapStyle.RoundCap"))
        pen.setJoinStyle(E(Qt, "PenJoinStyle.RoundJoin"))
        p.setPen(pen)
        p.setBrush(E(Qt, "BrushStyle.NoBrush"))
        if mark == "check":
            p.drawPolyline(QtGui.QPolygonF([QtCore.QPointF(21 * s, 32 * s), QtCore.QPointF(29 * s, 40 * s),
                                            QtCore.QPointF(43 * s, 24 * s)]))
        elif mark == "dots":
            for x in (22, 32, 42):
                p.drawPoint(QtCore.QPointF(x * s, 32 * s))
        elif mark == "off":
            p.drawLine(QtCore.QPointF(24 * s, 32 * s), QtCore.QPointF(40 * s, 32 * s))
        elif mark == "x":
            p.drawLine(QtCore.QPointF(25 * s, 25 * s), QtCore.QPointF(39 * s, 39 * s))
            p.drawLine(QtCore.QPointF(39 * s, 25 * s), QtCore.QPointF(25 * s, 39 * s))
        p.end()
        icon.addPixmap(pm)
    return icon


class Bridge(QtCore.QObject):
    """Результат фонового потока → функция в потоке окна (сигнал между потоками = очередь Qt)."""
    result = Signal(object, object)
    event = Signal(object)
    notify = Signal(str, str)

    def __init__(self):
        super().__init__()
        self.result.connect(self._deliver)

    @staticmethod
    def _deliver(cb, value):
        try:
            cb(value)
        except Exception:
            core.LOG.exception("ui callback")


def _aa(p):
    p.setRenderHint(E(QtGui.QPainter, "RenderHint.Antialiasing"))
    p.setRenderHint(E(QtGui.QPainter, "RenderHint.SmoothPixmapTransform"))


def _anim(parent, ms, cb, start=0.0, end=1.0):
    a = QtCore.QVariantAnimation(parent)
    a.setDuration(ms)
    a.setStartValue(float(start))
    a.setEndValue(float(end))
    a.setEasingCurve(QtCore.QEasingCurve(E(QtCore.QEasingCurve, "Type.InOutQuad")))
    a.valueChanged.connect(lambda v: cb(float(v)))
    return a


_MASCOTS = {}


def mascot_pixmap(kind: str):
    """Картинка героя из assets/ (mascot_connected / mascot_disconnected, .png или .jpg)."""
    if kind not in _MASCOTS:
        pm = None
        for ext in (".png", ".jpg", ".jpeg", ".webp"):
            path = os.path.join(ASSETS, MASCOT_NAMES.get(kind, "?") + ext)
            if os.path.isfile(path):
                q = QtGui.QPixmap(path)
                if not q.isNull():
                    pm = q
                    break
        _MASCOTS[kind] = pm
    return _MASCOTS[kind]


def app_icon() -> QtGui.QIcon:
    """Значок окна: щит на крышке люка (data/icons), иначе нарисованный зелёный щит."""
    icon = QtGui.QIcon()
    for size in (16, 22, 24, 32, 48, 64, 128, 256):
        path = os.path.join(ICONS_DIR, f"adguard-vpn-desktop-{size}.png")
        if os.path.isfile(path):
            icon.addFile(path, QtCore.QSize(size, size))
    return icon if not icon.isNull() else shield_icon(GREEN)


def faded(pm: QtGui.QPixmap, size: int) -> QtGui.QPixmap:
    """Квадратная картинка с мягко растворёнными краями — сливается с тёмным фоном."""
    out = QtGui.QPixmap(size, size)
    out.fill(QtGui.QColor(0, 0, 0, 0))
    p = QtGui.QPainter(out)
    _aa(p)
    sc = pm.scaled(size, size, E(Qt, "AspectRatioMode.KeepAspectRatioByExpanding"),
                   E(Qt, "TransformationMode.SmoothTransformation"))
    p.drawPixmap((size - sc.width()) // 2, (size - sc.height()) // 2, sc)
    p.setCompositionMode(E(QtGui.QPainter, "CompositionMode.CompositionMode_DestinationIn"))
    g = QtGui.QRadialGradient(QtCore.QPointF(size / 2, size / 2), size / 2)
    g.setColorAt(0.0, QtGui.QColor(0, 0, 0, 255))
    g.setColorAt(0.62, QtGui.QColor(0, 0, 0, 255))
    g.setColorAt(0.86, QtGui.QColor(0, 0, 0, 110))
    g.setColorAt(1.0, QtGui.QColor(0, 0, 0, 0))
    p.fillRect(0, 0, size, size, QtGui.QBrush(g))
    p.end()
    return out


class MascotView(QtWidgets.QWidget):
    """Герой над кнопкой: «disconnected» — черепаха стоит в полный рост, «connected» — спряталась под
    люком со щитом. Смена — плавным переходом (crossfade), края растворяются в фоне."""

    def __init__(self, height=230, parent=None):
        super().__init__(parent)
        self.setFixedHeight(height)
        self.kind = "disconnected"
        self.prev = None
        self.t = 1.0
        self._cache = {}
        self._a = _anim(self, 500, self._step)

    def _step(self, v):
        self.t = v
        self.update()

    def set_kind(self, kind: str):
        if kind == self.kind:
            return
        self.prev, self.kind = self.kind, kind
        self._a.stop()
        self.t = 0.0
        self._a.start()

    def _img(self, kind, size):
        key = (kind, size)
        if key not in self._cache:
            pm = mascot_pixmap(kind)
            self._cache[key] = faded(pm, size) if pm is not None else None
        return self._cache[key]

    def _draw(self, p, kind, opacity):
        size = self.height()
        img = self._img(kind, size)
        if img is None or opacity <= 0:
            return
        p.setOpacity(opacity)
        p.drawPixmap((self.width() - size) // 2, 0, img)
        p.setOpacity(1.0)

    def paintEvent(self, _ev):
        p = QtGui.QPainter(self)
        _aa(p)
        if self.prev and self.t < 1.0:
            self._draw(p, self.prev, 1.0 - self.t)
            self._draw(p, self.kind, self.t)
        else:
            self._draw(p, self.kind, 1.0)
        p.end()


class ConnectButton(QtWidgets.QAbstractButton):
    """Большая круглая кнопка включения: серая — выкл., зелёная — вкл., бегущая дуга — подключение."""

    def __init__(self, size=164, parent=None):
        super().__init__(parent)
        self.setFixedSize(size, size)
        self.setCursor(E(Qt, "CursorShape.PointingHandCursor"))
        self.mode = "off"            # off | on | busy | err
        self.hover = 0.0
        self.angle = 0
        self._ha = _anim(self, 180, self._set_hover)
        self.spin = QtCore.QTimer(self)
        self.spin.timeout.connect(self._spin)

    def _set_hover(self, v):
        self.hover = v
        self.update()

    def _spin(self):
        self.angle = (self.angle + 8) % 360
        self.update()

    def set_mode(self, mode: str):
        if mode == self.mode:
            return
        self.mode = mode
        if mode == "busy":
            self.spin.start(30)
        else:
            self.spin.stop()
        self.update()

    def _hover_to(self, end):
        self._ha.stop()
        self._ha.setStartValue(self.hover)
        self._ha.setEndValue(float(end))
        self._ha.start()

    def enterEvent(self, ev):
        self._hover_to(1.0)
        super().enterEvent(ev)

    def leaveEvent(self, ev):
        self._hover_to(0.0)
        super().leaveEvent(ev)

    def sizeHint(self):
        return self.size()

    def paintEvent(self, _ev):
        p = QtGui.QPainter(self)
        _aa(p)
        w = self.width()
        c = QtCore.QPointF(w / 2, w / 2)
        R = w / 2 - 4
        on, busy = self.mode == "on", self.mode == "busy"
        accent = QtGui.QColor(GREEN if on else YELLOW if busy else RED if self.mode == "err" else GREY)
        # свечение
        g = QtGui.QRadialGradient(c, R)
        a = QtGui.QColor(accent)
        a.setAlpha(int((110 if on else 45) + 60 * self.hover))
        g.setColorAt(0.70, a)
        a0 = QtGui.QColor(accent)
        a0.setAlpha(0)
        g.setColorAt(1.0, a0)
        p.setPen(E(Qt, "PenStyle.NoPen"))
        p.setBrush(QtGui.QBrush(g))
        p.drawEllipse(c, R, R)
        # кольцо
        ring = R * 0.80
        pen = QtGui.QPen(QtGui.QColor("#1c2f52"))
        pen.setWidthF(5)
        p.setPen(pen)
        p.setBrush(E(Qt, "BrushStyle.NoBrush"))
        p.drawEllipse(c, ring, ring)
        pen = QtGui.QPen(accent)
        pen.setWidthF(5)
        pen.setCapStyle(E(Qt, "PenCapStyle.RoundCap"))
        p.setPen(pen)
        rect = QtCore.QRectF(c.x() - ring, c.y() - ring, 2 * ring, 2 * ring)
        if busy:
            p.drawArc(rect, int(-self.angle * 16), 100 * 16)
        elif on or self.mode == "err":
            p.drawEllipse(c, ring, ring)
        # круг
        inner = R * 0.70
        if on:
            lg = QtGui.QLinearGradient(c.x(), c.y() - inner, c.x(), c.y() + inner)
            lg.setColorAt(0, QtGui.QColor("#7fd088").lighter(int(100 + 12 * self.hover)))
            lg.setColorAt(1, QtGui.QColor(GREEN_DARK))
            p.setBrush(QtGui.QBrush(lg))
        else:
            base = QtGui.QColor("#13233f")
            p.setBrush(base.lighter(int(100 + 25 * self.hover)))
        p.setPen(E(Qt, "PenStyle.NoPen"))
        p.drawEllipse(c, inner, inner)
        # значок питания
        ic = QtGui.QColor("#ffffff") if on else (QtGui.QColor(GREEN) if self.hover > 0.5 else QtGui.QColor("#9aa8c0"))
        if not self.isEnabled():
            ic = QtGui.QColor("#4d5d78")
        pen = QtGui.QPen(ic)
        pen.setWidthF(max(4.0, w / 26))
        pen.setCapStyle(E(Qt, "PenCapStyle.RoundCap"))
        p.setPen(pen)
        s = inner * 0.42
        p.drawArc(QtCore.QRectF(c.x() - s, c.y() - s + 3, 2 * s, 2 * s), 120 * 16, 300 * 16)
        p.drawLine(QtCore.QPointF(c.x(), c.y() - s - 4), QtCore.QPointF(c.x(), c.y() + 1))
        p.end()


class LocButton(QtWidgets.QPushButton):
    """Строка локации: слева флаг и название, справа пинг. Активная — с зелёной рамкой и ✅."""

    def __init__(self, parent=None, chevron=False):
        super().__init__(parent)
        self.setObjectName("loc")
        lay = QtWidgets.QHBoxLayout(self)
        lay.setContentsMargins(14, 8, 12, 8)
        self.left = QtWidgets.QLabel()
        self.right = QtWidgets.QLabel()
        self.right.setTextFormat(E(Qt, "TextFormat.RichText"))
        for w in (self.left, self.right):
            w.setAttribute(E(Qt, "WidgetAttribute.WA_TransparentForMouseEvents"))
        self.left.setMinimumWidth(10)
        self.left.setSizePolicy(E(QtWidgets.QSizePolicy, "Policy.Ignored"),
                                E(QtWidgets.QSizePolicy, "Policy.Preferred"))
        lay.addWidget(self.left, 1)
        lay.addWidget(self.right, 0)
        if chevron:
            ch = QtWidgets.QLabel("›")
            ch.setStyleSheet(f"color:{GREY}; font-size:16pt;")
            ch.setAttribute(E(Qt, "WidgetAttribute.WA_TransparentForMouseEvents"))
            lay.addWidget(ch, 0)
        self.setMinimumHeight(48)
        self.setCursor(E(Qt, "CursorShape.PointingHandCursor"))

    def set_content(self, text: str, right_html: str, active: bool = False):
        self.left.setText(text)
        self.left.setStyleSheet(f"color:{GREEN}; font-weight:bold;" if active else "")
        self.right.setText(right_html)
        if self.property("active") != active:
            self.setProperty("active", active)
            self.style().unpolish(self)
            self.style().polish(self)


def section(title: str):
    lbl = QtWidgets.QLabel(title.upper())
    lbl.setObjectName("sectionTitle")
    return lbl


def page_scroll():
    """Страница с прокруткой: (QScrollArea, вертикальная раскладка содержимого)."""
    scroll = QtWidgets.QScrollArea()
    scroll.setWidgetResizable(True)
    scroll.setFrameShape(E(QtWidgets.QFrame, "Shape.NoFrame"))
    scroll.setHorizontalScrollBarPolicy(E(Qt, "ScrollBarPolicy.ScrollBarAlwaysOff"))
    content = QtWidgets.QWidget()
    content.setObjectName("page")
    lay = QtWidgets.QVBoxLayout(content)
    lay.setContentsMargins(16, 10, 16, 14)
    lay.setSpacing(8)
    scroll.setWidget(content)
    scroll.viewport().setAutoFillBackground(False)
    content.setAutoFillBackground(False)
    return scroll, lay


def card(title: str = ""):
    """Секция-карточка: заголовок КАПСОМ сверху и тёмная подложка."""
    outer = QtWidgets.QWidget()
    v = QtWidgets.QVBoxLayout(outer)
    v.setContentsMargins(0, 6, 0, 0)
    v.setSpacing(4)
    lbl = None
    if title:
        lbl = QtWidgets.QLabel(title.upper())
        lbl.setObjectName("sectionTitle")
        v.addWidget(lbl)
    box = QtWidgets.QFrame()
    box.setObjectName("card")
    inner = QtWidgets.QVBoxLayout(box)
    inner.setContentsMargins(10, 10, 10, 10)
    inner.setSpacing(6)
    v.addWidget(box)
    outer.title_label = lbl
    return outer, inner


def kv_row(key: str):
    w = QtWidgets.QWidget()
    w.setObjectName("row")
    h = QtWidgets.QHBoxLayout(w)
    h.setContentsMargins(2, 0, 2, 0)
    k = QtWidgets.QLabel(key)
    k.setObjectName("key")
    val = QtWidgets.QLabel("…")
    val.setTextInteractionFlags(E(Qt, "TextInteractionFlag.TextSelectableByMouse"))
    val.setAlignment(E(Qt, "AlignmentFlag.AlignRight") | E(Qt, "AlignmentFlag.AlignVCenter"))
    h.addWidget(k)
    h.addStretch(1)
    h.addWidget(val)
    return w, val


def small(text: str = "", name: str = "muted"):
    lbl = QtWidgets.QLabel(text)
    lbl.setObjectName(name)
    lbl.setWordWrap(True)
    return lbl


def qr_pixmap(text: str, scale: int = 6, border: int = 3) -> QtGui.QPixmap:
    m = core.qr_matrix(text)
    n = len(m)
    size = (n + 2 * border) * scale
    img = QtGui.QImage(size, size, E(QtGui.QImage, "Format.Format_RGB32"))
    img.fill(QtGui.QColor("#ffffff"))
    p = QtGui.QPainter(img)
    p.setPen(E(Qt, "PenStyle.NoPen"))
    p.setBrush(QtGui.QColor("#000000"))
    for y, row in enumerate(m):
        for x, dark in enumerate(row):
            if dark:
                p.drawRect((x + border) * scale, (y + border) * scale, scale, scale)
    p.end()
    return QtGui.QPixmap.fromImage(img)


def status_label(s) -> str:
    if not s:
        return "Проверка…"
    err = s.get("error")
    if err == "cli_not_found":
        return "❌ adguardvpn-cli не найден"
    if err == "not_logged_in":
        return "🔒 Не выполнен вход"
    if err == "no_subscription":
        return "💳 Нет подписки / лимит"
    if err == "timeout":
        return "⏳ Нет ответа (медленная сеть?)"
    if err == "not_configured":
        return "⚙️ AdGuard ещё не настроен"
    if err == "killed":
        return "Проверка…"
    if err:
        return "Ошибка чтения статуса"
    return {"connected": "🟢 Включено", "connecting": "🟡 Подключение…", "reconnecting": "🟡 Переподключение…",
            "disconnected": "🔴 Отключено"}.get(s.get("state"), "Неизвестно")


LEVEL_ICON = {"info": "ℹ️", "ok": "✅", "warn": "⚠️", "error": "❌"}


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self, backend: core.Backend, bridge: Bridge):
        super().__init__()
        self.b, self.bridge = backend, bridge
        self.status = None
        self.locs = None
        self.favs = core.load_favorites()
        self.account = None
        self.setup = None
        self.ip = None
        self.upd = None
        self.settings = {}
        self.busy = None              # {"name", "since", "token"}
        self.token = 0
        self.last_error = ""
        self.login = None             # ответ login_start/login_poll
        self.login_starting = False
        self.updating = False
        self._inflight = set()
        self._hint_shown = False
        self._quitting = False
        ui = core.read_json(os.path.join(core.state_dir(), "ui.json"))
        self.frozen = ui.get("frozen") if isinstance(ui.get("frozen"), dict) else None
        self.last_sel = ui.get("last_sel") if isinstance(ui.get("last_sel"), dict) else None
        self.others_open = True               # 1.1: «Все локации» — отдельная вкладка, список открыт всегда
        self._rows_sig = None
        self._fav_sig = None
        self._combo_sig = None
        self._auto_acc = False

        self.setWindowTitle(APP_NAME)
        self.setWindowIcon(app_icon())
        self.resize(420, 800)
        self.setMinimumWidth(380)
        self._build()
        self.bridge.event.connect(self._on_event)
        self.bridge.notify.connect(self.notify)

        self.status_timer = QtCore.QTimer(self)
        self.status_timer.timeout.connect(self.refresh_status)
        self.status_timer.start(POLL_MS)
        self.tick = QtCore.QTimer(self)
        self.tick.timeout.connect(self._tick)
        self.tick.start(1000)
        self.slow_timer = QtCore.QTimer(self)
        self.slow_timer.timeout.connect(self._slow_refresh)
        self.slow_timer.start(LOC_REFRESH_MS)
        self.acc_timer = QtCore.QTimer(self)
        self.acc_timer.timeout.connect(lambda: self.refresh_account())
        self.acc_timer.start(ACCOUNT_REFRESH_MS)
        self.login_timer = QtCore.QTimer(self)
        self.login_timer.timeout.connect(self._login_poll)

        self.tray = None
        self._build_tray()
        self.render()

    # ---------------------------------------------------------------- фон

    def bg(self, fn, cb, *args, key=None):
        """fn(*args) в фоновом потоке → cb(результат) в потоке окна. key — не запускать дубль."""
        if key:
            if key in self._inflight:
                return
            self._inflight.add(key)

        def work():
            try:
                val = fn(*args)
            except Exception as e:
                core.LOG.exception(f"bg {getattr(fn, '__name__', fn)}")
                val = {"ok": False, "error": "exception", "message": f"Ошибка приложения: {e}"}

            def done(v, _cb=cb):
                if key:
                    self._inflight.discard(key)
                if _cb:
                    _cb(v)
            self.bridge.result.emit(done, val)
        threading.Thread(target=work, daemon=True, name=key or "bg").start()

    def _save_ui(self):
        try:
            core.write_json(os.path.join(core.state_dir(), "ui.json"),
                            {"frozen": self.frozen, "last_sel": self.last_sel, "others_open": self.others_open})
        except Exception:
            pass

    # ---------------------------------------------------------------- построение окна

    def _build(self):
        root_w = QtWidgets.QWidget()
        root_w.setObjectName("root")
        outer = QtWidgets.QVBoxLayout(root_w)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        self.setCentralWidget(root_w)

        # шапка
        headw = QtWidgets.QWidget()
        head = QtWidgets.QHBoxLayout(headw)
        head.setContentsMargins(16, 10, 16, 2)
        self.head_icon = QtWidgets.QLabel()
        self.head_icon.setPixmap(shield_icon(GREY, "off").pixmap(26, 26))
        title = QtWidgets.QLabel(APP_NAME)
        title.setObjectName("title")
        head.addWidget(self.head_icon)
        head.addWidget(title)
        head.addStretch(1)
        outer.addWidget(headw)

        self.pages = QtWidgets.QStackedWidget()
        outer.addWidget(self.pages, 1)

        # ===== 1. ГЛАВНАЯ: герой + большая кнопка =====
        self.scroll, root = page_scroll()
        self.page_main = self.scroll
        root.setContentsMargins(16, 0, 16, 8)
        root.setSpacing(4)
        self.setup_box, lay = card()
        self.setup_text = small("", "warnText")
        self.setup_text.setTextFormat(E(Qt, "TextFormat.RichText"))
        lay.addWidget(self.setup_text)
        root.addWidget(self.setup_box)

        self.mascot = MascotView(390)
        root.addWidget(self.mascot)
        self.conn_btn = ConnectButton(130)
        self.conn_btn.setToolTip("Включить / выключить VPN")
        self.conn_btn.clicked.connect(self._hero_clicked)
        hb = QtWidgets.QHBoxLayout()
        hb.addStretch(1)
        hb.addWidget(self.conn_btn)
        hb.addStretch(1)
        root.addSpacing(-80)
        root.addLayout(hb)

        self.v_state = QtWidgets.QLabel("Проверка…")
        self.v_state.setObjectName("bigState")
        self.v_state.setAlignment(E(Qt, "AlignmentFlag.AlignCenter"))
        root.addWidget(self.v_state)
        self.v_loc = QtWidgets.QLabel("")
        self.v_loc.setObjectName("subState")
        self.v_loc.setTextFormat(E(Qt, "TextFormat.RichText"))
        self.v_loc.setAlignment(E(Qt, "AlignmentFlag.AlignCenter"))
        self.v_loc.setWordWrap(True)
        root.addWidget(self.v_loc)
        self.v_ip = small("", "muted")
        self.v_ip.setAlignment(E(Qt, "AlignmentFlag.AlignCenter"))
        self.v_ip.setTextInteractionFlags(E(Qt, "TextInteractionFlag.TextSelectableByMouse"))
        root.addWidget(self.v_ip)
        self.v_busy = small("", "warnText")
        self.v_err = small("", "errText")
        self.v_hint = small("", "warnText")
        self.v_slow = small("")
        for x in (self.v_busy, self.v_err, self.v_hint, self.v_slow):
            x.setAlignment(E(Qt, "AlignmentFlag.AlignCenter"))
            root.addWidget(x)

        root.addSpacing(2)
        root.addWidget(section("Локация"))
        self.sel_btn = LocButton(chevron=True)
        self.sel_btn.setObjectName("selector")
        self.sel_btn.setMinimumHeight(56)
        self.sel_btn.setToolTip("Выбрать локацию")
        self.sel_btn.clicked.connect(lambda: self._go(1))
        root.addWidget(self.sel_btn)
        self.btn_off = QtWidgets.QPushButton("⛔ Отключить")
        self.btn_off.setObjectName("danger")
        self.btn_off.setMinimumHeight(42)
        self.btn_off.clicked.connect(lambda: self.do_action("off"))
        root.addWidget(self.btn_off)
        root.addStretch(1)
        self.pages.addWidget(self.page_main)

        # ===== 2. ЛОКАЦИИ =====
        self.page_locs, root = page_scroll()
        t = QtWidgets.QLabel("Локации")
        t.setObjectName("pageTitle")
        root.addWidget(t)
        self.search = QtWidgets.QLineEdit()
        self.search.setObjectName("search")
        self.search.setPlaceholderText("🔍 Поиск: страна или город")
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(lambda _t: self._render_rows(force=True))
        root.addWidget(self.search)
        root.addWidget(section("⚡ Самая быстрая"))
        self.btn_fastest = LocButton()
        self.btn_fastest.clicked.connect(self._click_fastest)
        root.addWidget(self.btn_fastest)
        root.addWidget(section("Быстрый выбор"))
        self.fixed_btns = {}
        for loc in FIXED:
            b = LocButton()
            b.clicked.connect(lambda _=False, l=loc: self._click_fixed(l))
            root.addWidget(b)
            self.fixed_btns[loc["id"]] = b
        self.fav_box = QtWidgets.QWidget()
        self.fav_box.setObjectName("row")
        fv = QtWidgets.QVBoxLayout(self.fav_box)
        fv.setContentsMargins(0, 0, 0, 0)
        fv.setSpacing(6)
        fv.addWidget(section("⭐ Избранное"))
        favw = QtWidgets.QWidget()
        favw.setObjectName("row")
        self.fav_lay = QtWidgets.QVBoxLayout(favw)
        self.fav_lay.setContentsMargins(0, 0, 0, 0)
        self.fav_lay.setSpacing(6)
        fv.addWidget(favw)
        root.addWidget(self.fav_box)
        self.btn_others = QtWidgets.QPushButton()      # совместимость: в 1.1 список «Все локации» открыт всегда
        self.btn_others.setObjectName("link")
        self.btn_others.clicked.connect(self._toggle_others)
        self.btn_others.hide()
        root.addWidget(section("Все локации"))
        self.others_note = small("")
        root.addWidget(self.others_note)
        self.others_wrap = QtWidgets.QWidget()
        self.others_wrap.setObjectName("row")
        self.others_lay = QtWidgets.QVBoxLayout(self.others_wrap)
        self.others_lay.setContentsMargins(0, 0, 0, 0)
        self.others_lay.setSpacing(6)
        root.addWidget(self.others_wrap)
        self.ping_note = small("")
        root.addWidget(self.ping_note)
        root.addStretch(1)
        self.pages.addWidget(self.page_locs)

        # ===== 3. АККАУНТ / ВХОД =====
        self.page_acc, root = page_scroll()
        self.login_mascot = MascotView(190)
        root.addWidget(self.login_mascot)
        self.acc_title = QtWidgets.QLabel("Аккаунт AdGuard")
        self.acc_title.setObjectName("pageTitle")
        self.acc_title.setAlignment(E(Qt, "AlignmentFlag.AlignCenter"))
        root.addWidget(self.acc_title)
        w, lay = card()
        self.acc_info = small("Проверка…", "muted")
        self.acc_info.setTextFormat(E(Qt, "TextFormat.RichText"))
        self.acc_info.setTextInteractionFlags(E(Qt, "TextInteractionFlag.TextSelectableByMouse"))
        lay.addWidget(self.acc_info)
        self.qr = QtWidgets.QLabel()
        self.qr.setAlignment(E(Qt, "AlignmentFlag.AlignCenter"))
        lay.addWidget(self.qr)
        self.login_text = small("")
        self.login_text.setTextFormat(E(Qt, "TextFormat.RichText"))
        self.login_text.setOpenExternalLinks(True)
        self.login_text.setTextInteractionFlags(E(Qt, "TextInteractionFlag.TextBrowserInteraction"))
        lay.addWidget(self.login_text)
        self.btn_login = QtWidgets.QPushButton("🔑 Войти в AdGuard")
        self.btn_login.setObjectName("primary")
        self.btn_login.setMinimumHeight(46)
        self.btn_login.clicked.connect(self.start_login)
        lay.addWidget(self.btn_login)
        lrow = QtWidgets.QHBoxLayout()
        self.btn_open = QtWidgets.QPushButton("🌐 Открыть ссылку")
        self.btn_open.clicked.connect(self._open_login_url)
        self.btn_copy = QtWidgets.QPushButton("📋 Копировать")
        self.btn_copy.clicked.connect(self._copy_login_url)
        lrow.addWidget(self.btn_open)
        lrow.addWidget(self.btn_copy)
        lay.addLayout(lrow)
        lrow2 = QtWidgets.QHBoxLayout()
        self.btn_check = QtWidgets.QPushButton("✔ Я подтвердил — проверить")
        self.btn_check.setObjectName("primary")
        self.btn_check.clicked.connect(self._login_speedup)
        self.btn_lcancel = QtWidgets.QPushButton("Отмена")
        self.btn_lcancel.clicked.connect(self._login_cancel)
        lrow2.addWidget(self.btn_check, 1)
        lrow2.addWidget(self.btn_lcancel)
        lay.addLayout(lrow2)
        self.btn_logout = QtWidgets.QPushButton("Выйти из аккаунта")
        self.btn_logout.clicked.connect(self._logout)
        lay.addWidget(self.btn_logout)
        root.addWidget(w)
        root.addStretch(1)
        self.pages.addWidget(self.page_acc)

        # ===== 4. НАСТРОЙКИ =====
        self.page_set, root = page_scroll()
        t = QtWidgets.QLabel("Настройки")
        t.setObjectName("pageTitle")
        root.addWidget(t)
        w, lay = card("Подключение")
        self.cb_auto = QtWidgets.QCheckBox("Подключаться при запуске приложения")
        self.cb_auto.toggled.connect(lambda v: self._set({"autoconnect": v}))
        lay.addWidget(self.cb_auto)
        self.combo_auto = QtWidgets.QComboBox()
        self.combo_auto.currentIndexChanged.connect(self._combo_changed)
        lay.addWidget(self.combo_auto)
        self.cb_reconnect = QtWidgets.QCheckBox("Переподключать при обрыве (3 попытки)")
        self.cb_reconnect.toggled.connect(lambda v: self._set({"reconnect": v}))
        lay.addWidget(self.cb_reconnect)
        root.addWidget(w)
        w, lay = card("Приложение")
        self.cb_autostart = QtWidgets.QCheckBox("Запускать вместе с рабочим столом")
        self.cb_autostart.toggled.connect(lambda v: self._set({"autostart": v}))
        lay.addWidget(self.cb_autostart)
        self.cb_min = QtWidgets.QCheckBox("Запускаться свёрнутым в трей")
        self.cb_min.toggled.connect(lambda v: self._set({"start_minimized": v}))
        lay.addWidget(self.cb_min)
        self.cb_notify = QtWidgets.QCheckBox("Уведомления")
        self.cb_notify.toggled.connect(lambda v: self._set({"notifications": v}))
        lay.addWidget(self.cb_notify)
        root.addWidget(w)
        w, lay = card("Дополнительно")
        self.upd_text = small("AdGuard VPN CLI: …")
        lay.addWidget(self.upd_text)
        self.btn_update = QtWidgets.QPushButton("Проверить обновление AdGuard")
        self.btn_update.clicked.connect(self._update_clicked)
        lay.addWidget(self.btn_update)
        self.btn_refresh = QtWidgets.QPushButton("🔄 Обновить статус, пинг и IP")
        self.btn_refresh.clicked.connect(self.refresh_all)
        lay.addWidget(self.btn_refresh)
        self.sudo_text = small("")
        lay.addWidget(self.sudo_text)
        root.addWidget(w)
        foot = QtWidgets.QLabel(f"by MaxFoley · сделано с помощью Grok Bot · v{VERSION}")
        foot.setObjectName("footer")
        foot.setAlignment(E(Qt, "AlignmentFlag.AlignCenter"))
        root.addWidget(foot)
        root.addStretch(1)
        self.pages.addWidget(self.page_set)

        # ===== 5. ЖУРНАЛ =====
        self.page_log, root = page_scroll()
        w, lay = card("📜 Журнал")
        self.journal_card = w
        jrow = QtWidgets.QHBoxLayout()
        self.cb_errors = QtWidgets.QCheckBox("Только ошибки")
        self.cb_errors.toggled.connect(lambda _v: self.render_journal())
        jrow.addWidget(self.cb_errors)
        jrow.addStretch(1)
        b = QtWidgets.QPushButton("📂 Файлы")
        b.setToolTip(core.state_dir())
        b.clicked.connect(lambda: QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(core.state_dir())))
        jrow.addWidget(b)
        b = QtWidgets.QPushButton("Очистить")
        b.clicked.connect(self._clear_journal)
        jrow.addWidget(b)
        lay.addLayout(jrow)
        self.journal = QtWidgets.QListWidget()
        self.journal.setMinimumHeight(320)
        self.journal.setWordWrap(True)
        self.journal.currentItemChanged.connect(self._journal_selected)
        lay.addWidget(self.journal)
        self.journal_details = QtWidgets.QPlainTextEdit()
        self.journal_details.setReadOnly(True)
        self.journal_details.setMaximumHeight(170)
        self.journal_details.hide()
        lay.addWidget(self.journal_details)
        root.addWidget(w)
        root.addStretch(1)
        self.pages.addWidget(self.page_log)

        # нижняя панель вкладок (как в мобильном приложении)
        nav = QtWidgets.QWidget()
        nav.setObjectName("navbar")
        nav.setAttribute(E(Qt, "WidgetAttribute.WA_StyledBackground"), True)
        nl = QtWidgets.QHBoxLayout(nav)
        nl.setContentsMargins(8, 6, 8, 8)
        nl.setSpacing(4)
        self.nav_group = QtWidgets.QButtonGroup(self)
        self.nav_group.setExclusive(True)
        self.nav_btns = []
        for i, txt in enumerate(("🔒\nVPN", "🌍\nЛокации", "👤\nАккаунт", "⚙\nНастройки", "📜\nЖурнал")):
            b = QtWidgets.QPushButton(txt)
            b.setObjectName("nav")
            b.setCheckable(True)
            b.setCursor(E(Qt, "CursorShape.PointingHandCursor"))
            b.setMinimumHeight(48)
            b.clicked.connect(lambda _=False, n=i: self._go(n))
            self.nav_group.addButton(b, i)
            nl.addWidget(b, 1)
            self.nav_btns.append(b)
        self.nav_btns[0].setChecked(True)
        outer.addWidget(nav)
        root_w.setAttribute(E(Qt, "WidgetAttribute.WA_StyledBackground"), True)

    def _go(self, n: int):
        self.pages.setCurrentIndex(n)
        self.nav_btns[n].setChecked(True)
        if n == 1:
            self.refresh_locations(False)
            self._render_rows(force=True)

    def _hero_clicked(self):
        st = self.status or {}
        if self.busy or st.get("busy") or self._connected() or st.get("state") in ("connecting", "reconnecting"):
            self.do_action("off")
            return
        if st.get("error") == "not_logged_in" or (self.account and self.account.get("logged_in") is False):
            self._go(2)
            if not (self.login and self.login.get("running")):
                self.start_login()
            return
        key = (self.last_sel or {}).get("key") or "fastest"
        for loc in FIXED:
            if fixed_key(loc["id"]) == key:
                return self._click_fixed(loc)
        r = next((r for r in self._rows() if loc_key(r) == key), None)
        if r is not None:
            return self._click_row(r)
        self._click_fastest()

    def _selector_content(self):
        """Строка «Локация» на главной: текущая (если включено) или та, к которой подключит кнопка."""
        rows = self._rows()
        key = self._active_key() if self._connected() else (self.last_sel or {}).get("key") or "fastest"
        if key == "fastest" and not self._connected():
            f = self._fastest()
            right = ping_html(f["ping"]) if f else ping_html(None)
            sub = f"{flag_of(f['iso'])} {label_of(f, rows)}" if f else ""
            return "⚡ Самая быстрая" + (f"  <span style='color:{GREY}'>· {sub}</span>" if sub else ""), right
        for loc in FIXED:
            if fixed_key(loc["id"]) == key:
                ms, fr = self._shown_ping(key, self._live_ping_fixed(loc))
                return f"{flag_of(loc['iso'])} {loc['label']}", ping_html(ms, fr)
        r = next((r for r in rows if loc_key(r) == key), None) or self._matched_other()
        if r is not None:
            ms, fr = self._shown_ping(loc_key(r), r.get("ping"))
            return f"{flag_of(r['iso'])} {label_of(r, rows)}", ping_html(ms, fr)
        if self._connected():
            return f"🌐 {self._cur_label() or 'неизвестно'}", ping_html(None)
        return "⚡ Самая быстрая", ping_html(None)

    def render_hero(self):
        st = self.status or {}
        busy = self.busy or st.get("busy") or st.get("state") in ("connecting", "reconnecting")
        off_busy = bool(self.busy and self.busy.get("name") == "Отключение")
        if busy:
            mode, state, text = "busy", "busy", ("Отключение…" if off_busy else "Подключение…")
        elif self._connected():
            mode, state, text = "on", "on", "Подключено"
        elif st.get("error") and st.get("error") != "killed":
            mode, state, text = "err", "err", status_label(st)
        elif st.get("state") == "disconnected":
            mode, state, text = "off", "off", "Отключено"
        else:
            mode, state, text = "off", "off", status_label(self.status)
        self.conn_btn.set_mode(mode)
        self.mascot.set_kind("connected" if mode == "on" else "disconnected")
        self.login_mascot.set_kind("disconnected")
        if self.v_state.text() != text or self.v_state.property("state") != state:
            self.v_state.setText(text)
            self.v_state.setProperty("state", state)
            self.v_state.style().unpolish(self.v_state)
            self.v_state.style().polish(self.v_state)
        left, right = self._selector_content()
        self.sel_btn.left.setTextFormat(E(Qt, "TextFormat.RichText"))
        self.sel_btn.set_content(left, right, self._connected())
        self.btn_off.setText("⛔ Отменить и отключить" if self.busy else "⛔ Отключить")
        self.btn_off.setVisible(bool(self._connected() or busy))

    # ---------------------------------------------------------------- трей

    def _build_tray(self):
        if not QtWidgets.QSystemTrayIcon.isSystemTrayAvailable():
            core.LOG.warning("системный трей недоступен — закрытие окна завершит приложение")
            return
        self.tray = QtWidgets.QSystemTrayIcon(shield_icon(GREY, "off"), self)
        self.tray_menu = QtWidgets.QMenu()
        self.tray_menu.aboutToShow.connect(self._fill_tray_menu)
        self._fill_tray_menu()
        self.tray.setContextMenu(self.tray_menu)
        self.tray.activated.connect(self._tray_activated)
        self.tray.setToolTip(APP_NAME)
        self.tray.show()

    def _tray_activated(self, reason):
        if reason in (E(QtWidgets.QSystemTrayIcon, "ActivationReason.Trigger"),
                      E(QtWidgets.QSystemTrayIcon, "ActivationReason.DoubleClick")):
            if self.isVisible() and not self.isMinimized():
                self.hide()
                self._retime()
            else:
                self.show_window()

    def _fill_tray_menu(self):
        m = self.tray_menu
        m.clear()
        a = m.addAction(f"{status_label(self.status)}" + (f" · {self._cur_label()}" if self._connected() else ""))
        a.setEnabled(False)
        if self.busy:
            a = m.addAction(f"⏳ {self.busy['name']}…")
            a.setEnabled(False)
        m.addSeparator()
        busy = self.busy is not None
        a = m.addAction("⚡ Самая быстрая")
        a.setEnabled(not busy)
        a.triggered.connect(self._click_fastest)
        active = self._active_key()
        for loc in FIXED:
            on = active == fixed_key(loc["id"])
            a = m.addAction(f"{'✅' if on else flag_of(loc['iso'])} {loc['label']}")
            a.setEnabled(not busy)
            a.triggered.connect(lambda _=False, l=loc: self._click_fixed(l))
        rows = self._rows()
        fav_rows = [r for r in rows if r["iso"] not in FIXED_ISO and loc_key(r) in self.favs]
        if fav_rows:
            sub = m.addMenu("⭐ Избранное")
            for r in fav_rows:
                on = active == loc_key(r)
                a = sub.addAction(f"{'✅' if on else flag_of(r['iso'])} {label_of(r, rows)}")
                a.setEnabled(not busy)
                a.triggered.connect(lambda _=False, row=r: self._click_row(row))
        m.addSeparator()
        a = m.addAction("⛔ Отменить и отключить" if busy else "⛔ Отключить")
        a.triggered.connect(lambda: self.do_action("off"))
        m.addSeparator()
        m.addAction("🪟 Показать окно").triggered.connect(self.show_window)
        m.addAction("Выход").triggered.connect(self.quit_app)

    def _update_tray(self):
        st = self.status or {}
        busy = self.busy or st.get("busy")
        if busy or st.get("state") in ("connecting", "reconnecting"):
            color, mark, tip = YELLOW, "dots", "подключение…"
        elif st.get("connected"):
            color, mark, tip = GREEN, "check", f"включено · {self._cur_label()}"
        elif st.get("error") in ("not_logged_in", "cli_not_found", "no_subscription"):
            color, mark, tip = RED, "x", status_label(st)
        else:
            color, mark, tip = GREY, "off", status_label(st)
        sig = (color, mark)
        if getattr(self, "_icon_sig", None) != sig:
            self._icon_sig = sig
            icon = shield_icon(color, mark)
            self.head_icon.setPixmap(icon.pixmap(26, 26))
            if self.tray:
                self.tray.setIcon(icon)
        if self.tray:
            self.tray.setToolTip(f"{APP_NAME}: {tip}")

    def notify(self, title: str, body: str = ""):
        """Короткое уведомление рабочего стола (через значок в трее)."""
        if not self.settings.get("notifications", True):
            return
        if self.tray and self.tray.supportsMessages():
            self.tray.showMessage(title[:60], body[:80], self.tray.icon(), 4000)

    def show_window(self):
        self.showNormal()
        self.raise_()
        self.activateWindow()
        self._retime()
        self.refresh_all(force=False)

    def closeEvent(self, ev):
        if self.tray and self.tray.isVisible() and not self._quitting:
            ev.ignore()
            self.hide()
            self._retime()
            if not self._hint_shown:
                self._hint_shown = True
                self.notify("AdGuard VPN работает в трее", "Выход — через меню значка")
            return
        self._quitting = True
        self.b.stop()
        ev.accept()
        QtWidgets.QApplication.instance().quit()

    def quit_app(self):
        self._quitting = True
        self.b.stop()
        if self.tray:
            self.tray.hide()
        QtWidgets.QApplication.instance().quit()

    def _retime(self):
        self.status_timer.setInterval(POLL_MS if self.isVisible() else POLL_HIDDEN_MS)

    # ---------------------------------------------------------------- обновление данных

    def refresh_all(self, force=True):
        self.refresh_status()
        self.refresh_locations(force)
        self.refresh_ip(force)
        self.refresh_account()
        self.bg(self.b.get_settings, self._on_settings, key="settings")
        self.favs = core.load_favorites()
        self.render_journal()

    def initial_load(self):
        self.bg(self.b.get_settings, self._on_settings, key="settings")
        self.refresh_status()
        self.refresh_locations(False)
        self.refresh_ip(False)
        self.refresh_account()
        self.bg(self.b.check_setup, self._on_setup, key="setup")
        self.bg(self.b.check_update, self._on_update, False, key="update")
        self.render_journal()

    def _slow_refresh(self):
        if self.isVisible():
            self.refresh_locations(False)
            self.refresh_ip(False)
        self.favs = core.load_favorites()       # плагин мог поменять избранное

    def refresh_status(self):
        self.bg(self.b.get_status, self._on_status, key="status")

    def refresh_locations(self, force=False):
        self.bg(self.b.get_locations, self._on_locations, force, key="locations")

    def refresh_ip(self, force=False):
        self.bg(self.b.get_ip, self._on_ip, force, key="ip")

    def refresh_account(self):
        if self.login and self.login.get("running"):
            return
        self.bg(self.b.account_info, self._on_account, key="account")

    def _on_status(self, st):
        if not isinstance(st, dict) or st.get("error") == "exception":
            return
        if st.get("error") == "killed" and self.status:
            return                                   # прервано входом — оставляем прошлый статус
        prev = self.status
        self.status = st
        if prev and prev.get("connected") != st.get("connected"):
            self.refresh_ip(True)                    # VPN включили/выключили (может быть из плагина)
        self.render()

    def _on_locations(self, d):
        if isinstance(d, dict) and "locations" in d:
            self.locs = d
            self.render()

    def _on_ip(self, d):
        if isinstance(d, dict):
            self.ip = d
            self.render()

    def _on_account(self, d):
        if isinstance(d, dict) and "logged_in" in d:
            self.account = d
            self.render_account()

    def _on_setup(self, d):
        if isinstance(d, dict) and "items" in d:
            self.setup = d
            self.render()

    def _on_update(self, d):
        if isinstance(d, dict) and "installed" in d:
            self.upd = d
            self.render_extra()

    def _on_settings(self, d):
        if isinstance(d, dict) and "autoconnect" in d:
            self.settings = d
            self.render_settings()

    def _on_event(self, _ev):
        self.render_journal()

    def _set(self, changes):
        if getattr(self, "_rendering_settings", False):
            return
        self.settings.update(changes)
        self.bg(self.b.set_settings, self._on_settings, changes)

    def _combo_changed(self, _i):
        if getattr(self, "_rendering_settings", False):
            return
        data = self.combo_auto.currentData()
        if data:
            self._set({"autoconnect_action": data,
                       "autoconnect_label": "" if data == "last" else self.combo_auto.currentText()})

    # ---------------------------------------------------------------- действия

    def _click_fastest(self):
        f = self._fastest()
        self.do_action("fastest", {"key": "fastest", "label": "Самая быстрая", "ms": f["ping"] if f else None})

    def _click_fixed(self, loc):
        self.do_action(loc["id"], {"key": fixed_key(loc["id"]), "label": loc["label"],
                                   "ms": self._live_ping_fixed(loc)})

    def _click_row(self, r):
        rows = self._rows()
        self.do_action("loc:" + target_of(r, rows), {"key": loc_key(r), "label": label_of(r, rows),
                                                      "ms": r.get("ping")})

    def do_action(self, action, sel=None):
        if self.busy and action != "off":
            return
        self.token += 1
        tok = self.token
        label = (sel or {}).get("label", "")
        self.busy = {"name": "Отключение" if action == "off" else f"Подключение: {label}",
                     "since": time.monotonic(), "token": tok}
        self.last_error = ""
        if sel:
            self.last_sel = {"key": sel["key"], "label": sel["label"]}
            self._save_ui()
        self.render()

        def done(res):
            if tok == self.token:
                self.busy = None
            if not isinstance(res, dict):
                return
            if res.get("ok"):
                if action == "off":
                    self.frozen = None
                    self.notify("⛔ VPN отключён", "")
                else:
                    if sel:
                        self.frozen = {"key": sel["key"], "ms": sel.get("ms")}
                    self.notify(f"✅ {label or 'VPN'}", "VPN подключён" if not res.get("warning") else res["warning"])
                self._save_ui()
            elif res.get("cancelled"):
                if tok == self.token:
                    self.notify("Отменено", "")
            else:
                lab = res.get("error_label") or "Ошибка"
                self.last_error = lab if not res.get("message") else f"{lab}: {res['message'][:120]}"
                self.notify(f"❌ {lab.replace('Ошибка: ', '')}"[:60], "Подробности — в Журнале")
            if res.get("status"):
                self.status = dict(res["status"], busy={})
            self.render()
            self.refresh_status()
            QtCore.QTimer.singleShot(3000, lambda: self.refresh_ip(True))
            QtCore.QTimer.singleShot(1500, self.refresh_status)
        self.bg(self.b.run_action, done, action, label, "user")

    # ---------------------------------------------------------------- вход

    def start_login(self):
        if self.login_starting:
            return
        self.login_starting = True
        self.login = {"running": True}
        self.render_account()

        def done(res):
            self.login_starting = False
            self._on_login(res)
            if isinstance(res, dict) and res.get("running"):
                self.login_timer.start(2000)
        self.bg(self.b.login_start, done)

    def _login_poll(self):
        self.bg(self.b.login_poll, self._on_login, key="login_poll")

    def _login_speedup(self):
        self.bg(self.b.login_speedup, self._on_login, key="login_speedup")

    def _login_cancel(self):
        self.login_timer.stop()

        def done(_r):
            self.login = None
            self.render_account()
            self.refresh_account()
        self.bg(self.b.login_cancel, done)

    def _on_login(self, res):
        if not isinstance(res, dict):
            return
        if res.get("ok") is False:
            self.login = None
            self.login_timer.stop()
            self.acc_info.setText(f"<span style='color:{RED}'>❌ {res.get('message', 'Ошибка входа')}</span>")
            self.render_account(keep_info=True)
            return
        self.login = res
        if res.get("done"):
            self.login_timer.stop()
            self.login = None
            self.notify("✅ Вход выполнен", "AdGuard VPN готов")
            self._auto_acc = False
            self.account = None                   # старый ответ «вход не выполнен» больше не верен
            self._go(0)
            self.refresh_account()
            self.refresh_status()
            self.refresh_locations(True)
        elif not res.get("running"):
            self.login_timer.stop()
            self.login = dict(res, failed=True)
            self.refresh_account()
        self.render_account()

    def _open_login_url(self):
        url = (self.login or {}).get("url")
        if url and not QtGui.QDesktopServices.openUrl(QtCore.QUrl(url)):
            webbrowser.open(url)

    def _copy_login_url(self):
        url = (self.login or {}).get("url")
        if url:
            QtWidgets.QApplication.clipboard().setText(url)
            self.notify("📋 Ссылка скопирована", "")

    def _logout(self):
        if QtWidgets.QMessageBox.question(self, APP_NAME, "Выйти из аккаунта AdGuard?") != \
                E(QtWidgets.QMessageBox, "StandardButton.Yes"):
            return
        self.btn_logout.setEnabled(False)

        def done(res):
            self.btn_logout.setEnabled(True)
            if isinstance(res, dict):
                self.notify("Выход из аккаунта" if res.get("ok") else "❌ Не удалось выйти", "")
            self.account = None
            self.refresh_account()
            self.refresh_status()
        self.bg(self.b.logout, done)

    # ---------------------------------------------------------------- обновление CLI

    def _update_clicked(self):
        if self.updating:
            return
        if self.upd and self.upd.get("update_available"):
            self.updating = True
            self.render_extra()

            def done(res):
                self.updating = False
                ok = isinstance(res, dict) and res.get("ok")
                self.notify("✅ AdGuard обновлён" if ok else "❌ Ошибка обновления", "" if ok else "См. Журнал")
                self.bg(self.b.check_update, self._on_update, True, key="update")
            self.bg(self.b.run_update, done)
        else:
            self.upd_text.setText("AdGuard VPN CLI: проверяю…")
            self.bg(self.b.check_update, self._on_update, True, key="update")

    def _clear_journal(self):
        self.b.events.clear()
        self.render_journal()

    def _toggle_others(self):
        self.others_open = not self.others_open
        self._save_ui()
        if self.others_open:
            self.refresh_locations(False)
        self._render_rows(force=True)

    def _tick(self):
        if self.busy or (self.status or {}).get("busy"):
            self.render_status_busy()
        if self.login and self.login.get("running") and self.login.get("seconds_left"):
            self.login["seconds_left"] = max(0, self.login["seconds_left"] - 1)
            self._render_login_text()

    # ---------------------------------------------------------------- вычисляемое (как в плагине)

    def _rows(self):
        return (self.locs or {}).get("locations") or []

    def _connected(self):
        return bool(self.status and self.status.get("connected"))

    def _status_city(self):
        return norm_city((self.status or {}).get("location_text") or "") if self._connected() else ""

    def _matched_other(self):
        city = self._status_city()
        if not city:
            return None
        return next((r for r in self._rows() if r["iso"] not in FIXED_ISO and norm_city(r["city"]) == city), None)

    def _active_key(self):
        if not self._connected():
            return None
        if self.status.get("location"):
            return fixed_key(self.status["location"])
        m = self._matched_other()
        if m:
            return loc_key(m)
        if self._status_city():
            return None
        return (self.last_sel or {}).get("key")

    def _cur_label(self):
        key = self._active_key()
        for loc in FIXED:
            if fixed_key(loc["id"]) == key:
                return loc["label"]
        m = self._matched_other()
        if m:
            return label_of(m, self._rows())
        if key and (self.last_sel or {}).get("key") == key:
            return self.last_sel.get("label", "")
        return ((self.status or {}).get("location_text") or "").title()

    def _live_ping_fixed(self, loc):
        cs = [r for r in cities_of(self._rows(), loc["iso"]) if r.get("ping") is not None]
        if not cs:
            return None
        if self._active_key() == fixed_key(loc["id"]):
            conn = next((r for r in cs if norm_city(r["city"]) == self._status_city()), None)
            if conn:
                return conn["ping"]
        return min(r["ping"] for r in cs)

    def _shown_ping(self, key, live):
        f = self.frozen
        if key == self._active_key() and f and f.get("key") == key and f.get("ms") is not None:
            return f["ms"], True
        return live, False

    def _fastest(self):
        rows = [r for r in self._rows() if r.get("ping") is not None]
        return min(rows, key=lambda r: r["ping"]) if rows else None

    # ---------------------------------------------------------------- отрисовка

    def render(self):
        self.render_status()
        self.render_locations()
        self._render_rows()
        self.render_account()
        self.render_extra()
        self._update_tray()

    def render_status_busy(self):
        st = self.status or {}
        if self.busy:
            sec = int(time.monotonic() - self.busy["since"])
            txt = f"⏳ {self.busy['name']} {sec} с"
            if sec > 15:
                txt += "\nДолго? «⛔ Отключить» отменит подключение. Подробности — в «📜 Журнал»."
        elif st.get("busy"):
            b = st["busy"]
            txt = f"🔄 {b.get('name')}{' (ждёт плагин)' if b.get('waiting_lock') else ''} {b.get('seconds', 0)} с"
        else:
            txt = ""
        self.v_busy.setText(txt)
        self.v_busy.setVisible(bool(txt))

    def render_status(self):
        st = self.status
        self.render_hero()
        if self._connected():
            lt = st.get("location_text") or ""
            cur = self._cur_label() or "неизвестно"
            extra = f" ({lt})" if lt and cur.upper() != lt.upper() else ""
            self.v_loc.setText(f"📍 <span style='color:{GREEN};font-weight:bold'>{cur}{extra}</span>")
        elif st and not st.get("error") and not self.busy and not st.get("busy") \
                and st.get("state") not in ("connecting", "reconnecting"):
            self.v_loc.setText(f"<span style='color:{GREY}'>Нажмите кнопку, чтобы подключиться</span>")
        else:
            self.v_loc.setText("")
        ip = self.ip
        if ip and ip.get("ok"):
            cc = ip.get("country") or ""
            self.v_ip.setText(f"IP: {ip['ip']} ({COUNTRY_RU.get(cc, cc or '?')})")
        else:
            self.v_ip.setText("IP: не определён" if ip else "IP: …")
        self.v_err.setText(f"❌ {self.last_error} · см. «📜 Журнал»" if self.last_error else "")
        self.v_err.setVisible(bool(self.last_error))
        err = (st or {}).get("error")
        hint = {
            "not_logged_in": "Войдите в аккаунт: вкладка «👤 Аккаунт» внизу (или нажмите большую кнопку).",
            "timeout": "adguardvpn-cli не ответил за 75 сек. Обычно это медленная сеть: перед каждой командой "
                       "он связывается с серверами AdGuard. Приложение продолжает проверять само.",
            "not_configured": "AdGuard ещё не настроен. Выполните в терминале: "
                              "adguardvpn-cli config set-crash-reporting off",
            "cli_not_found": "Программа adguardvpn-cli не установлена. Запустите установщик: "
                             "bash install-adguard-vpn-desktop.sh",
        }.get(err, "")
        self.v_hint.setText(hint)
        self.v_hint.setVisible(bool(hint))
        slow = (st or {}).get("slow")
        self.v_slow.setText(f"adguardvpn-cli отвечает медленно ({round(slow)} сек.) — сеть медленная"
                            if slow and not err else "")
        self.v_slow.setVisible(bool(slow and not err))
        self.render_status_busy()
        # предупреждение об установке
        miss = (self.setup or {}).get("missing") or []
        if miss:
            items = "".join(f"<li>{i['label']}{(' — ' + i['hint']) if i.get('hint') else ''}</li>" for i in miss)
            self.setup_text.setText(f"<b>⚠️ Установка не завершена</b><ul style='margin:4px 0 0 -20px'>{items}</ul>"
                                    "Запустите установщик ещё раз: <code>bash install-adguard-vpn-desktop.sh</code>")
        self.setup_box.setVisible(bool(miss))

    def render_locations(self):
        busy = self.busy is not None
        rows = self._rows()
        active = self._active_key()
        f = self._fastest()
        right = (f"{flag_of(f['iso'])} {label_of(f, rows)} · {ping_html(f['ping'])}" if f else ping_html(None))
        self.btn_fastest.set_content("⚡ Самая быстрая", right, False)
        self.btn_fastest.setEnabled(not busy)
        for loc in FIXED:
            key = fixed_key(loc["id"])
            on = key == active
            ms, frozen = self._shown_ping(key, self._live_ping_fixed(loc))
            b = self.fixed_btns[loc["id"]]
            b.set_content(f"{'✅' if on else flag_of(loc['iso'])} {loc['label']}", ping_html(ms, frozen), on)
            b.setEnabled(not busy)
        self.btn_off.setText("⛔ Отменить и отключить" if busy else "⛔ Отключить")
        src = (self.locs or {}).get("source")
        if not self.locs:
            note = "Пинг: загружаю список локаций… (на медленной сети до минуты)"
        elif src == "fallback":
            note = "Пинг недоступен: adguardvpn-cli не ответил (встроенный список локаций)"
        else:
            note = f"Пинг — оценка AdGuard, обновлён {self.locs.get('age', 0)} с назад. 📌 — пинг при подключении."
        self.ping_note.setText(note)

    def _row_widget(self, r, rows, active, busy):
        w = QtWidgets.QWidget()
        w.setObjectName("row")
        h = QtWidgets.QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(6)
        key = loc_key(r)
        on = key == active
        ms, frozen = self._shown_ping(key, r.get("ping"))
        b = LocButton()
        b.set_content(f"{'✅' if on else flag_of(r['iso'])} {label_of(r, rows)}", ping_html(ms, frozen), on)
        b.setEnabled(not busy)
        b.clicked.connect(lambda _=False, row=r: self._click_row(row))
        fav = key in self.favs
        s = QtWidgets.QPushButton("★" if fav else "☆")
        s.setObjectName("star")
        s.setToolTip("Убрать из избранного" if fav else "В избранное")
        s.setProperty("fav", fav)
        s.clicked.connect(lambda _=False, k=key, v=not fav: self._toggle_fav(k, v))
        h.addWidget(b, 1)
        h.addWidget(s)
        return w

    def _toggle_fav(self, key, on):
        self.favs = [k for k in self.favs if k != key] + ([key] if on else [])
        self._render_rows(force=True)

        def done(favs):
            if isinstance(favs, list):
                self.favs = favs
                self._render_rows(force=True)
                self.render_settings()
        self.bg(self.b.set_favorite, done, key, on)

    def _render_rows(self, force=False):
        rows = self._rows()
        busy = self.busy is not None
        active = self._active_key()
        other = [r for r in rows if r["iso"] not in FIXED_ISO]

        def sort_key(r):
            return (0, r["ping"], "") if r.get("ping") is not None else (1, 0, label_of(r, rows))
        fav_rows = sorted([r for r in other if loc_key(r) in self.favs], key=sort_key)
        q = self.search.text().strip().lower()
        rest = sorted([r for r in other if loc_key(r) not in self.favs], key=sort_key)
        shown = [r for r in rest if not q or q in label_of(r, rows).lower() or q in r["country"].lower()
                 or q in r["city"].lower() or q == r["iso"].lower()]
        frozen_sig = tuple((self.frozen or {}).items())
        sig = (tuple((loc_key(r), r.get("ping")) for r in rows), tuple(self.favs), active, busy, frozen_sig,
               self.others_open, q)
        if sig == self._rows_sig and not force:
            return
        self._rows_sig = sig
        # избранное
        while self.fav_lay.count():
            it = self.fav_lay.takeAt(0)
            if it.widget():
                it.widget().hide()
                it.widget().deleteLater()
        for r in fav_rows:
            self.fav_lay.addWidget(self._row_widget(r, rows, active, busy))
        self.fav_box.setVisible(bool(fav_rows))
        # другие
        self.btn_others.setText(f"{'▾' if self.others_open else '▸'} Показать другие ({len(rest)})")
        self.search.setVisible(self.others_open)
        src = (self.locs or {}).get("source")
        self.others_note.setText("Встроенный список: adguardvpn-cli сейчас не ответил, пинга нет"
                                 if src == "fallback" else "☆ — добавить в избранное. Пинг виден до подключения.")
        self.others_note.setVisible(self.others_open)
        self.others_wrap.setUpdatesEnabled(False)
        while self.others_lay.count():
            it = self.others_lay.takeAt(0)
            if it.widget():
                it.widget().hide()
                it.widget().deleteLater()
        if self.others_open:
            for r in shown:
                self.others_lay.addWidget(self._row_widget(r, rows, active, busy))
            if not shown:
                self.others_lay.addWidget(small("Ничего не найдено" if q else "Список пуст"))
        self.others_wrap.setVisible(self.others_open)
        self.others_wrap.setUpdatesEnabled(True)

    def render_account(self, keep_info=False):
        acc = self.account
        lg = self.login
        login_active = bool(lg and (lg.get("running") or lg.get("failed")))
        if not keep_info:
            if login_active:
                self.acc_info.setText("Вход через браузер: отсканируйте QR-код телефоном или откройте ссылку "
                                      "и подтвердите вход в аккаунте AdGuard.")
            elif acc is None:
                self.acc_info.setText("Проверка…")
            elif not acc.get("cli"):
                self.acc_info.setText(f"<span style='color:{RED}'>adguardvpn-cli не установлен</span>")
            elif acc.get("logged_in"):
                parts = [f"<b style='color:{GREEN}'>✅ Вход выполнен</b>"]
                if acc.get("email"):
                    parts.append(f"Аккаунт: <b>{acc['email']}</b>")
                if acc.get("plan"):
                    plan = {"PREMIUM": "Premium 💎", "FREE": "Бесплатный"}.get(acc["plan"], acc["plan"].title())
                    parts.append(f"Тариф: <b>{plan}</b>")
                if acc.get("until"):
                    parts.append(("Продление: " if acc.get("renews") else "Действует до: ") + f"<b>{acc['until']}</b>")
                if acc.get("devices"):
                    parts.append(f"Устройств: до {acc['devices']}")
                if acc.get("traffic_left"):
                    parts.append(f"Осталось трафика: {acc['traffic_left']}")
                if acc.get("traffic_out"):
                    parts.append(f"<span style='color:{RED}'>Бесплатный трафик закончился — скорость ограничена</span>")
                if acc.get("no_subscription"):
                    parts.append(f"<span style='color:{RED}'>Подписка истекла или лимит исчерпан</span>")
                self.acc_info.setText("<br>".join(parts))
            elif acc.get("logged_in") is False:
                self.acc_info.setText(f"<b style='color:{YELLOW}'>🔒 Вход не выполнен</b><br>"
                                      "Без входа VPN не подключится. Вход — через браузер, пароль приложение не видит.")
            else:
                self.acc_info.setText("Не удалось проверить вход (медленная сеть?). Если не входили — нажмите «Войти».")
        logged = bool(acc and acc.get("logged_in"))
        self.acc_title.setText("Аккаунт AdGuard" if logged else "Вход в AdGuard VPN")
        if acc and acc.get("logged_in") is False and not self._auto_acc:
            self._auto_acc = True                 # не выполнен вход — один раз сами открываем экран входа
            self._go(2)
        self.btn_login.setVisible(not logged and not (lg and lg.get("running")))
        self.btn_login.setEnabled(not self.login_starting)
        self.btn_login.setText("⏳ Запускаю вход…" if self.login_starting else "🔑 Войти в AdGuard")
        self.btn_logout.setVisible(logged and not login_active)
        has_url = bool(lg and lg.get("url") and lg.get("running"))
        for w in (self.btn_open, self.btn_copy, self.btn_check, self.btn_lcancel):
            w.setVisible(bool(lg and lg.get("running")))
        self.btn_open.setEnabled(has_url)
        self.btn_copy.setEnabled(has_url)
        if has_url:
            url = lg["url"]
            if getattr(self, "_qr_url", None) != url:
                self._qr_url = url
                try:
                    self.qr.setPixmap(qr_pixmap(url, 5))
                except Exception as e:
                    core.LOG.warning(f"QR: {e}")
                    self.qr.setText("(QR-код не построился — используйте ссылку)")
            self.qr.setVisible(True)
        else:
            self.qr.setVisible(False)
            self._qr_url = None
        self._render_login_text()

    def _render_login_text(self):
        lg = self.login
        if not lg:
            self.login_text.setVisible(False)
            return
        if lg.get("failed") or lg.get("error"):
            txt = f"<span style='color:{RED}'>❌ Вход не выполнен: {lg.get('error') or ''}</span>"
        elif lg.get("url"):
            left = lg.get("seconds_left") or 0
            txt = (f"Ссылка: <a style='color:{BLUE}' href='{lg['url']}'>{lg['url']}</a>"
                   + (f"<br>Код: <b style='font-size:13pt'>{lg['code']}</b>" if lg.get("code") else "")
                   + (f"<br>Осталось: {left // 60}:{left % 60:02d}" if left else "")
                   + "<br>После подтверждения в браузере нажмите «✔ Я подтвердил — проверить».")
        else:
            txt = "⏳ Жду ссылку от AdGuard… (на медленной сети до минуты)"
        self.login_text.setText(txt)
        self.login_text.setVisible(True)

    def render_settings(self):
        s = self.settings
        if not s:
            return
        self._rendering_settings = True
        try:
            self.cb_auto.setChecked(s.get("autoconnect", False))
            self.cb_reconnect.setChecked(s.get("reconnect", False))
            self.cb_autostart.setChecked(s.get("autostart", False))
            self.cb_min.setChecked(s.get("start_minimized", False))
            self.cb_notify.setChecked(s.get("notifications", True))
            rows = self._rows()
            last = s.get("last_label") or ""
            opts = [("last", "Последняя локация" + (f" ({last})" if last else "")), ("fastest", "⚡ Самая быстрая")]
            opts += [(l["id"], f"{flag_of(l['iso'])} {l['label']}") for l in FIXED]
            opts += [("loc:" + target_of(r, rows), f"⭐ {label_of(r, rows)}") for r in rows
                     if r["iso"] not in FIXED_ISO and loc_key(r) in self.favs]
            cur = s.get("autoconnect_action", "last")
            if cur not in [o[0] for o in opts] and s.get("autoconnect_label"):
                opts.append((cur, s["autoconnect_label"]))
            sig = (tuple(opts), cur)
            if sig != self._combo_sig:
                self._combo_sig = sig
                self.combo_auto.clear()
                for data, text in opts:
                    self.combo_auto.addItem(text, data)
                idx = max(0, [o[0] for o in opts].index(cur) if cur in [o[0] for o in opts] else 0)
                self.combo_auto.setCurrentIndex(idx)
            self.combo_auto.setEnabled(s.get("autoconnect", False))
        finally:
            self._rendering_settings = False

    def render_extra(self):
        u = self.upd
        if self.updating:
            self.upd_text.setText("⏳ Обновляю AdGuard VPN CLI… (до нескольких минут)")
            self.btn_update.setEnabled(False)
        elif u:
            inst = u.get("installed") or "?"
            if u.get("update_available"):
                self.upd_text.setText(f"AdGuard VPN CLI: {inst} → доступна {u['latest']}")
                self.btn_update.setText(f"⬆ Обновить AdGuard до {u['latest']}")
            else:
                tail = " (последняя)" if u.get("latest") else (" (GitHub недоступен)" if u.get("error") else "")
                self.upd_text.setText(f"AdGuard VPN CLI: {inst}{tail}")
                self.btn_update.setText("Проверить обновление AdGuard")
            self.btn_update.setEnabled(True)
        self.btn_refresh.setEnabled(True)
        sitem = next((i for i in (self.setup or {}).get("items", []) if i["id"] == "sudo"), None)
        if sitem is not None:
            self.sudo_text.setText("🔐 Права администратора: правило sudo без пароля есть" if sitem["ok"] else
                                   "🔐 Пароль администратора будет спрашиваться окном при подключении. "
                                   "Чтобы не спрашивал — запустите установщик ещё раз.")

    def render_journal(self):
        items = self.b.events.list(errors_only=self.cb_errors.isChecked())
        sel = self.journal.currentItem()
        sel_id = sel.data(E(Qt, "ItemDataRole.UserRole")) if sel else None
        self.journal.blockSignals(True)
        self.journal.clear()
        for ev in items:
            it = QtWidgets.QListWidgetItem(f"{LEVEL_ICON.get(ev['level'], 'ℹ️')} {ev['time']}  {ev['summary']}")
            it.setData(E(Qt, "ItemDataRole.UserRole"), ev["id"])
            it.setToolTip(f"{ev.get('date', '')} {ev['time']}")
            if ev["level"] == "error":
                it.setForeground(QtGui.QColor(RED))
            elif ev["level"] == "warn":
                it.setForeground(QtGui.QColor(YELLOW))
            elif ev["level"] == "ok":
                it.setForeground(QtGui.QColor(GREEN))
            self.journal.addItem(it)
            if ev["id"] == sel_id:
                self.journal.setCurrentItem(it)
        if not items:
            self.journal.addItem("Пусто" if not self.cb_errors.isChecked() else "Ошибок нет 👍")
        self.journal.blockSignals(False)

    def _journal_selected(self, cur, _prev):
        if cur is None:
            self.journal_details.hide()
            return
        ev_id = cur.data(E(Qt, "ItemDataRole.UserRole"))
        ev = next((e for e in self.b.events.list() if e["id"] == ev_id), None)
        if not ev:
            self.journal_details.hide()
            return
        self.journal_details.setPlainText(f"{ev.get('date', '')} {ev['time']}  {ev['summary']}\n\n{ev['details']}")
        self.journal_details.show()
