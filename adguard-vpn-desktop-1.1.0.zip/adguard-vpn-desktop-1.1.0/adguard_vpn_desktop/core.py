"""
AdGuard VPN для рабочего стола — «мозги» приложения (без Qt, только стандартная библиотека Python).

Всё работает от ОБЫЧНОГО пользователя: adguardvpn-cli вызывается напрямую, его вход и настройки —
в ~/.local/share/adguardvpn-cli (те же, что у плагина для игрового режима, поэтому оба видят
один и тот же VPN). Права администратора CLI просит сам через sudo: если есть правило «sudo без
пароля» (создаёт установщик) — без вопросов, иначе sudo покажет окно пароля (SUDO_ASKPASS).

Уроки плагина, которые здесь учтены:
  * никаких обязательных pty/termios: вход — через os.openpty(), termios — по возможности;
  * вывод CLI — во временный ФАЙЛ, не в pipe (connect оставляет демон, который держит pipe);
  * каждая команда — в своей группе процессов, жёсткие тайм-ауты, убийство всей группы;
  * действия (connect/disconnect/update) — по одному; статус и журнал при этом не блокируются;
  * вход прерывает зависшее подключение и зависшие status/license;
  * медленная сеть: CLI перед каждой командой 30–40 сек. тянет свой конфиг → тайм-ауты 75–150 сек.;
  * ни одна функция отсюда не вызывается в потоке интерфейса (их зовут фоновые потоки).

Совместная работа с плагином для игрового режима:
  * общий замок на команды, меняющие VPN: flock на $XDG_RUNTIME_DIR/adguard-vpn-cli.lock
    (/run/user/<uid>/…; если папки нет — /tmp/adguard-vpn-cli-<uid>.lock);
  * общий файл «что хотел пользователь»: ~/.local/state/adguard-vpn/desired.json — сторож и
    автоподключение не включают VPN обратно, если последним пользователь нажал «Отключить»
    (в приложении ИЛИ в плагине; state.json плагина тоже читается);
  * избранное — общее с плагином (~/homebrew/settings/adguard-vpn/favorites.json), если плагин есть.
"""

import json
import logging
import os
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request

try:                                    # есть на любом Linux, но не роняем приложение, если нет
    import fcntl
except Exception:                       # pragma: no cover
    fcntl = None

from . import VERSION

LOG = logging.getLogger("adguard-vpn-desktop")

# ---------- время (медленная сеть: CLI перед КАЖДОЙ командой связывается с AdGuard) ----------
STATUS_TIMEOUT = 75          # status / license / --version
PING_TIMEOUT = 90            # list-locations
ACTION_SOFT_TIMEOUT = 90     # дальше — предупреждение в Журнале
ACTION_HARD_TIMEOUT = 150    # дальше — connect/disconnect убиваем
UPDATE_TIMEOUT = 600
LOCK_WAIT = 150              # сколько ждём, пока плагин закончит свою команду
PROGRESS_EVERY = 30          # «connect идёт N с…» в Журнал
SLOW_CLI_SECONDS = 10
PING_CACHE_SECONDS = 45
IP_CACHE_SECONDS = 60
UPDATE_CACHE_SECONDS = 6 * 3600
SUDO_CACHE_SECONDS = 300
WATCHDOG_INTERVAL = 30
RECONNECT_DELAYS = (10, 30, 60)
AUTOCONNECT_DELAY = 8
AUTOCONNECT_WAIT = 180
EVENTS_MAX = 100

CLI_NAME = "adguardvpn-cli"
GITHUB_LATEST = "https://api.github.com/repos/AdguardTeam/AdGuardVPNCLI/releases/latest"
ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]|\x1b\][^\x07]*\x07|\r")


def strip_ansi(text: str) -> str:
    return ANSI_RE.sub("", text or "")


# =====================================================================================
#  Пути
# =====================================================================================

def home() -> str:
    return os.path.expanduser("~")


def _xdg(var: str, default: str) -> str:
    v = os.environ.get(var)
    return v if v and os.path.isabs(v) else os.path.join(home(), default)


def config_dir() -> str:
    return os.path.join(_xdg("XDG_CONFIG_HOME", ".config"), "adguard-vpn-desktop")


def state_dir() -> str:
    return os.path.join(_xdg("XDG_STATE_HOME", ".local/state"), "adguard-vpn-desktop")


def shared_dir() -> str:
    """Общая папка с плагином (маркер «что хотел пользователь»)."""
    return os.path.join(_xdg("XDG_STATE_HOME", ".local/state"), "adguard-vpn")


def plugin_settings_dir() -> str:
    return os.path.join(home(), "homebrew", "settings", "adguard-vpn")


def autostart_path() -> str:
    return os.path.join(_xdg("XDG_CONFIG_HOME", ".config"), "autostart", "adguard-vpn-desktop.desktop")


def data_path(*parts) -> str:
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", *parts)


def lock_path() -> str:
    uid = os.getuid()
    rd = os.environ.get("XDG_RUNTIME_DIR") or f"/run/user/{uid}"
    if os.path.isdir(rd) and os.access(rd, os.W_OK):
        return os.path.join(rd, "adguard-vpn-cli.lock")
    return os.path.join(tempfile.gettempdir(), f"adguard-vpn-cli-{uid}.lock")


def _ensure(d: str) -> str:
    os.makedirs(d, exist_ok=True)
    return d


def setup_logging() -> str:
    path = os.path.join(_ensure(state_dir()), "app.log")
    try:
        if os.path.exists(path) and os.path.getsize(path) > 1_000_000:
            os.replace(path, path + ".old")
        if not any(getattr(h, "baseFilename", None) == path for h in LOG.handlers):
            h = logging.FileHandler(path, encoding="utf-8")
            h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
            LOG.addHandler(h)
        LOG.setLevel(logging.INFO)
    except Exception as e:
        print(f"app.log недоступен: {e}", file=sys.stderr)
    return path


def read_json(path: str) -> dict:
    try:
        with open(path, encoding="utf-8") as f:
            v = json.load(f)
            return v if isinstance(v, dict) else {}
    except FileNotFoundError:
        return {}
    except Exception as e:
        LOG.warning(f"{path}: {e}")
        return {}


def write_json(path: str, data: dict) -> None:
    _ensure(os.path.dirname(path))
    tmp = f"{path}.{os.getpid()}.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)


# =====================================================================================
#  Разбор вывода adguardvpn-cli (те же правила, что в плагине 1.1.1)
# =====================================================================================

STATUS_LINE_RE = re.compile(
    r"\b(?P<state>connected|waiting to reconnect|waiting to connect|reconnecting)\s+to\s+"
    r"(?P<loc>.+?)\s+in\s+(?P<mode>\S+)\s+mode", re.IGNORECASE)
ACTIVE_RE = re.compile(r"\bvpn (is )?active\b", re.IGNORECASE)
STARTING_RE = re.compile(r"\bvpn is starting\b", re.IGNORECASE)
DISCONNECTED_RE = re.compile(r"\b(vpn is disconnected|disconnected|not connected)\b", re.IGNORECASE)
AUTH_RE = re.compile(r"(not logged in|please log in|log in first|login required|adguardvpn-cli login|"
                     r"unauthori[sz]ed|session (has )?expired)", re.IGNORECASE)
LICENSE_RE = re.compile(r"(subscription (has )?expired|no (active )?subscription|license (has )?expired|"
                        r"limit (is |has been )?(reached|exceeded))", re.IGNORECASE)
CONSENT_RE = re.compile(r"(crash report|send (anonymous )?(usage|statistics|crash)|usage data|telemetry|"
                        r"may we|would you like|do you (want|agree)|\[y/n\]|\(y/n\)|\[Y/n\]|\[y/N\])",
                        re.IGNORECASE)

FIXED = [  # первые 4 кнопки, как в плагине
    {"id": "Slovakia", "label": "Словакия", "iso": "SK"},
    {"id": "Germany", "label": "Германия", "iso": "DE"},
    {"id": "Sweden", "label": "Швеция", "iso": "SE"},
    {"id": "Kazakhstan", "label": "Казахстан", "iso": "KZ"},
]
FIXED_IDS = {f["id"] for f in FIXED}
FIXED_ISO = {f["iso"] for f in FIXED}
LOCATION_HINTS = {
    "Slovakia": ["slovakia", "bratislava", "kosice", "(sk)"],
    "Germany": ["germany", "frankfurt", "berlin", "munich", "dusseldorf", "hamburg", "(de)"],
    "Sweden": ["sweden", "stockholm", "gothenburg", "malmo", "(se)"],
    "Kazakhstan": ["kazakhstan", "astana", "almaty", "(kz)"],
}

COUNTRY_RU = {
    "AE": "ОАЭ", "AR": "Аргентина", "AT": "Австрия", "AU": "Австралия", "BE": "Бельгия", "BG": "Болгария",
    "BR": "Бразилия", "CA": "Канада", "CH": "Швейцария", "CL": "Чили", "CN": "Китай", "CO": "Колумбия",
    "CY": "Кипр", "CZ": "Чехия", "DE": "Германия", "DK": "Дания", "EE": "Эстония", "EG": "Египет",
    "ES": "Испания", "FI": "Финляндия", "FR": "Франция", "GB": "Великобритания", "GR": "Греция",
    "HK": "Гонконг", "HR": "Хорватия", "HU": "Венгрия", "ID": "Индонезия", "IE": "Ирландия", "IL": "Израиль",
    "IN": "Индия", "IR": "Иран", "IS": "Исландия", "IT": "Италия", "JP": "Япония", "KH": "Камбоджа",
    "KR": "Южная Корея", "KZ": "Казахстан", "LT": "Литва", "LU": "Люксембург", "LV": "Латвия",
    "MD": "Молдова", "MX": "Мексика", "MY": "Малайзия", "NG": "Нигерия", "NL": "Нидерланды",
    "NO": "Норвегия", "NP": "Непал", "NZ": "Новая Зеландия", "PE": "Перу", "PH": "Филиппины",
    "PK": "Пакистан", "PL": "Польша", "PT": "Португалия", "RO": "Румыния", "RS": "Сербия", "RU": "Россия",
    "SA": "Саудовская Аравия", "SE": "Швеция", "SG": "Сингапур", "SK": "Словакия", "TH": "Таиланд",
    "TR": "Турция", "TW": "Тайвань", "UA": "Украина", "US": "США", "VN": "Вьетнам", "ZA": "ЮАР",
    "AL": "Албания", "EC": "Эквадор",
}
CITY_RU = {
    "Frankfurt": "Франкфурт", "Berlin": "Берлин", "Barcelona": "Барселона", "Madrid": "Мадрид",
    "Paris": "Париж", "Marseille": "Марсель", "London": "Лондон", "Manchester": "Манчестер", "Rome": "Рим",
    "Milan": "Милан", "Palermo": "Палермо", "Vancouver": "Ванкувер", "Montreal": "Монреаль",
    "Toronto": "Торонто", "New York": "Нью-Йорк", "Boston": "Бостон", "Miami": "Майами", "Dallas": "Даллас",
    "Phoenix": "Финикс", "Chicago": "Чикаго", "Seattle": "Сиэтл", "Denver": "Денвер", "Atlanta": "Атланта",
    "Las Vegas": "Лас-Вегас", "Silicon Valley": "Кремниевая долина", "Los Angeles": "Лос-Анджелес",
}


def flag_of(iso: str) -> str:
    if iso and re.fullmatch(r"[A-Z]{2}", iso):
        return "".join(chr(0x1F1E6 + ord(c) - 65) for c in iso)
    return "🌐"


def detect_location(text: str):
    low = (text or "").lower()
    for loc, hints in LOCATION_HINTS.items():
        if any(h in low for h in hints):
            return loc
    return None


def parse_status(raw: str, code: int) -> dict:
    text = strip_ansi(raw).strip()
    state, loc_text = "unknown", ""
    m = STATUS_LINE_RE.search(text)
    if m:
        state = "connected" if m.group("state").lower() == "connected" else "reconnecting"
        loc_text = m.group("loc").strip()
    elif code == 10 or ACTIVE_RE.search(text):
        state = "connected"
    elif STARTING_RE.search(text):
        state = "connecting"
    elif DISCONNECTED_RE.search(text):
        state = "disconnected"
    error = None
    if state != "connected":
        if AUTH_RE.search(text):
            error = "not_logged_in"
        elif LICENSE_RE.search(text):
            error = "no_subscription"
    return {"state": state, "connected": state == "connected", "location": detect_location(loc_text),
            "location_text": loc_text, "raw": text, "code": code, "error": error}


LOCATION_ROW_RE = re.compile(r"^(?P<iso>[A-Z]{2})\s{2,}(?P<country>.+?)\s{2,}(?P<city>.+?)\s{2,}(?P<ping>\d+)\s*$")


def parse_locations(text: str) -> list:
    rows = []
    for line in strip_ansi(text).splitlines():
        m = LOCATION_ROW_RE.match(line.rstrip())
        if m:
            rows.append({"iso": m.group("iso"), "country": m.group("country").strip(),
                         "city": m.group("city").strip(), "ping": int(m.group("ping"))})
    return rows


def fallback_locations() -> list:
    try:
        with open(data_path("locations_fallback.json"), encoding="utf-8") as f:
            return [dict(r, ping=None) for r in json.load(f)["locations"]]
    except Exception as e:
        LOG.warning(f"locations_fallback.json: {e}")
        return []


def norm_city(s: str) -> str:
    return re.sub(r"\(VIRTUAL\)", "", (s or "").upper()).strip()


def loc_key(r: dict) -> str:
    """Ключ избранного — тот же формат, что у плагина: «ISO|Город»."""
    return f"{r['iso']}|{r['city']}"


def fixed_key(loc_id: str) -> str:
    return f"fixed:{loc_id}"


def cities_of(rows: list, iso: str) -> list:
    return [r for r in rows if r["iso"] == iso]


def target_of(r: dict, rows: list) -> str:
    """Что передать в `connect -l`: город, если в стране городов несколько, иначе страну."""
    if not r.get("city") or len(cities_of(rows, r["iso"])) <= 1:
        return r["country"]
    return r["city"]


def label_of(r: dict, rows: list) -> str:
    country = COUNTRY_RU.get(r["iso"], r["country"])
    virtual = " (вирт.)" if re.search(r"virtual", r.get("city") or "", re.I) else ""
    if r.get("city") and len(cities_of(rows, r["iso"])) > 1:
        city = re.sub(r"\s*\(virtual\)", "", r["city"], flags=re.I)
        return f"{country} — {CITY_RU.get(city, city)}{virtual}"
    return country + virtual


LOC_TARGET_RE = re.compile(r"^[^\W_][\w .,'()\-]{0,63}$")


def location_target(action: str):
    if not action.startswith("loc:"):
        return None
    t = action[4:].strip()
    return t if LOC_TARGET_RE.match(t) else None


LOGIN_URL_RE = re.compile(r"https?://[^\s<>\"'`]+", re.IGNORECASE)
LOGIN_CODE_RE = re.compile(r"user_code=([A-Z0-9-]{4,})|\bcode[^A-Za-z0-9]{1,5}([A-Z0-9]{4}-[A-Z0-9]{4})\b",
                           re.IGNORECASE)
LOGIN_TTL_RE = re.compile(r"available for\s+(\d+)\s+seconds", re.IGNORECASE)
LOGIN_OK_RE = re.compile(r"successfully logged in|logged in as|you are already logged in|already logged in",
                         re.IGNORECASE)
LOGIN_FAIL_RE = re.compile(r"(failed[^\r\n]*|error[^\r\n]*|expired[^\r\n]*|cancel+ed[^\r\n]*|timed? ?out[^\r\n]*)",
                           re.IGNORECASE)


def extract_login_url(text: str) -> str:
    """Ссылка входа (бывает и на зеркале со случайным доменом) — предпочитаем ту, где device_code/user_code."""
    urls = [u.rstrip(".,;:)]}'\"") for u in LOGIN_URL_RE.findall(strip_ansi(text or ""))]
    urls = [u for u in urls if re.match(r"https?://[\w.-]+\.[a-z]{2,}", u, re.IGNORECASE)]
    for u in urls:
        if re.search(r"device_code|user_code", u, re.IGNORECASE):
            return u
    https = [u for u in urls if u.lower().startswith("https://")]
    return (https or urls or [""])[0]


def parse_license(out: str) -> dict:
    t = strip_ansi(out or "")
    info = {"email": "", "plan": "", "until": "", "renews": False, "devices": None,
            "traffic_left": "", "traffic_out": False}
    m = re.search(r"logged in as\s+(\S+@\S+)", t, re.IGNORECASE) or re.search(r"[\w.+-]+@[\w-]+\.[\w.-]+", t)
    if m:
        info["email"] = (m.group(1) if m.groups() else m.group(0)).rstrip(".,")
    m = re.search(r"using the\s+(\w+)\s+version", t, re.IGNORECASE) or \
        re.search(r"\b(premium|free|unlimited|trial)\b", t, re.IGNORECASE)
    if m:
        info["plan"] = m.group(1).upper()
    m = re.search(r"(valid until|renewed on|expires?(?: on)?|until)\s*:?\s*(\d{4}-\d{2}-\d{2}|\d{2}\.\d{2}\.\d{4})",
                  t, re.IGNORECASE)
    if m:
        d = m.group(2)
        info["until"] = ".".join(reversed(d.split("-"))) if "-" in d else d
        info["renews"] = "renew" in m.group(1).lower()
    m = re.search(r"up to\s+(\d+)\s+devices?", t, re.IGNORECASE) or re.search(r"(\d+)\s+devices?", t, re.IGNORECASE)
    if m:
        info["devices"] = int(m.group(1))
    m = re.search(r"(\d+(?:[.,]\d+)?)\s*(KB|MB|GB|TB)\b[^\n]*?\b(left|remaining)", t, re.IGNORECASE) or \
        re.search(r"(?:left|remaining)[^\n\d]*(\d+(?:[.,]\d+)?)\s*(KB|MB|GB|TB)\b", t, re.IGNORECASE)
    if m:
        info["traffic_left"] = f"{m.group(1).replace(',', '.')} {m.group(2).upper()}"
    info["traffic_out"] = bool(re.search(r"out of free (vpn )?traffic|traffic limit reached", t, re.IGNORECASE))
    return info


SUDO_LABEL = "Ошибка: нет прав администратора (sudo)"
ERROR_LABELS = [
    (re.compile(r"not logged in|please log in|log in first|login required|unauthori[sz]ed|session (has )?expired",
                re.I), "Ошибка: не выполнен вход"),
    (re.compile(r"password is required|a terminal is required|askpass|sudo:|not in the sudoers|"
                r"incorrect password|authentication failure|permission denied|not permitted", re.I), SUDO_LABEL),
    (re.compile(r"нет ответа|timed? ?out|timeout|тайм-аут", re.I), "Ошибка: тайм-аут AdGuard"),
    (re.compile(r"network (is )?unreachable|no internet|could not resolve|name resolution|connection refused|"
                r"failed to connect to (the )?(server|endpoint)|no route to host|network error", re.I),
     "Ошибка: нет сети"),
    (re.compile(r"location .*(not found|unavailable|not available)|no such location|unknown location|"
                r"недопустимое имя локации|not available on (your|the free)", re.I), "Ошибка: локация недоступна"),
    (re.compile(r"traffic limit|out of free (vpn )?traffic", re.I), "Ошибка: закончился трафик"),
    (re.compile(r"too many devices", re.I), "Ошибка: много устройств"),
    (re.compile(r"subscription (has )?expired|license (has )?expired|no (active )?subscription", re.I),
     "Ошибка: нет подписки"),
]


def explain_error(text: str) -> str:
    for rx, label in ERROR_LABELS:
        if rx.search(text or ""):
            return label
    return "Ошибка"


def version_tuple(v: str):
    m = re.search(r"(\d+)\.(\d+)(?:\.(\d+))?", v or "")
    return tuple(int(x or 0) for x in m.groups()) if m else None


# =====================================================================================
#  QR-код: python-qrcode, если установлен, иначе встроенный qrcodegen (Project Nayuki, MIT)
# =====================================================================================

def qr_matrix(text: str) -> list:
    """Матрица True/False (тёмный модуль) без тихой зоны."""
    try:
        import qrcode                                   # type: ignore
        q = qrcode.QRCode(border=0, error_correction=qrcode.constants.ERROR_CORRECT_M)
        q.add_data(text)
        q.make(fit=True)
        return [list(map(bool, row)) for row in q.get_matrix()]
    except Exception:
        pass
    from .qrcodegen import QrCode
    q = QrCode.encode_text(text, QrCode.Ecc.MEDIUM)
    return [[q.get_module(x, y) for x in range(q.get_size())] for y in range(q.get_size())]


# =====================================================================================
#  Общий с плагином замок (flock) — команды, меняющие VPN, не идут одновременно
# =====================================================================================

class SharedLock:
    def __init__(self, path: str = None):
        self.path = path or lock_path()
        self._fd = None
        self._mu = threading.Lock()

    def _open(self):
        for flags in (os.O_RDWR | os.O_CREAT, os.O_RDONLY):
            try:
                fd = os.open(self.path, flags | getattr(os, "O_CLOEXEC", 0), 0o666)
                try:
                    os.fchmod(fd, 0o666)     # чтобы и плагин, и приложение могли открыть файл
                except OSError:
                    pass
                return fd
            except OSError:
                continue
        return None

    def acquire(self, wait: float, cancel: threading.Event = None) -> bool:
        """True — замок наш. Ждём не дольше wait; cancel прерывает ожидание."""
        if fcntl is None:
            return True
        deadline = time.monotonic() + wait
        while True:
            with self._mu:
                if self._fd is None:
                    fd = self._open()
                    if fd is None:
                        LOG.warning(f"замок {self.path} не открывается — работаю без него")
                        return True
                    try:
                        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                        self._fd = fd
                        try:
                            os.ftruncate(fd, 0)
                            os.write(fd, f"adguard-vpn-desktop pid={os.getpid()}\n".encode())
                        except OSError:
                            pass
                        return True
                    except OSError:
                        os.close(fd)
            if cancel is not None and cancel.is_set():
                return False
            if time.monotonic() >= deadline:
                return False
            time.sleep(0.25)

    def release(self) -> None:
        with self._mu:
            fd, self._fd = self._fd, None
        if fd is not None:
            try:
                fcntl.flock(fd, fcntl.LOCK_UN)
            finally:
                os.close(fd)

    def held_by_other(self) -> bool:
        if fcntl is None or self._fd is not None:
            return False
        fd = self._open()
        if fd is None:
            return False
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            fcntl.flock(fd, fcntl.LOCK_UN)
            return False
        except OSError:
            return True
        finally:
            os.close(fd)


# =====================================================================================
#  Журнал событий (показывается в окне, «📜 Журнал»)
# =====================================================================================

class Events:
    def __init__(self):
        self.path = os.path.join(state_dir(), "events.json")
        self._mu = threading.Lock()
        self.items = [e for e in read_json(self.path).get("events", []) if isinstance(e, dict)][-EVENTS_MAX:]
        self.listeners = []

    def add(self, level: str, summary: str, details: str = "") -> dict:
        ev = {"id": time.time_ns(), "time": time.strftime("%H:%M:%S"), "date": time.strftime("%d.%m"),
              "level": level if level in ("info", "ok", "warn", "error") else "info",
              "summary": (summary or "")[:90], "details": strip_ansi(details or "")[-4000:]}
        with self._mu:
            self.items.append(ev)
            del self.items[:-EVENTS_MAX]
            snapshot = list(self.items)
        try:
            write_json(self.path, {"events": snapshot})
        except Exception as e:
            LOG.warning(f"events.json: {e}")
        LOG.info(f"[{ev['level']}] {ev['summary']}" + (f" | {ev['details'][:300]!r}" if ev["details"] else ""))
        for cb in list(self.listeners):
            try:
                cb(ev)
            except Exception:
                pass
        return ev

    def list(self, errors_only: bool = False) -> list:
        with self._mu:
            items = list(reversed(self.items))          # новые сверху
        if errors_only:
            items = [e for e in items if e["level"] in ("error", "warn")]
        return items

    def clear(self) -> None:
        with self._mu:
            self.items.clear()
        write_json(self.path, {"events": []})


# =====================================================================================
#  Запуск adguardvpn-cli
# =====================================================================================

def kill_group(proc, grace: float = 2.0) -> None:
    """Убить процесс и всю его группу (start_new_session=True → pgid == pid)."""
    if proc is None or proc.poll() is not None:
        return
    for sig in (signal.SIGTERM, signal.SIGKILL):
        try:
            os.killpg(proc.pid, sig)
        except Exception:
            try:
                proc.send_signal(sig)
            except Exception:
                pass
        try:
            proc.wait(timeout=grace)
            return
        except Exception:
            continue


def find_cli():
    env = os.environ.get("ADGUARD_VPN_CLI")
    if env:
        return env if os.path.exists(env) else None
    for p in ("/usr/local/bin/adguardvpn-cli", "/opt/adguardvpn_cli/adguardvpn-cli",
              os.path.join(home(), ".local/bin/adguardvpn-cli")):
        if os.path.exists(p):
            return p
    return shutil.which(CLI_NAME)


CLEAN_ENV_DROP = ("PYTHONPATH", "PYTHONHOME", "LD_LIBRARY_PATH", "LD_PRELOAD", "QT_PLUGIN_PATH",
                  "QT_QPA_PLATFORM_PLUGIN_PATH", "VIRTUAL_ENV")


def _file_tail(path: str, n: int = 600) -> str:
    try:
        with open(path, "rb") as f:
            f.seek(max(0, os.path.getsize(path) - n))
            return strip_ansi(f.read().decode("utf-8", "replace")).strip()
    except Exception:
        return ""


class CliRunner:
    def __init__(self, events: Events):
        self.events = events
        self._procs = set()           # чтения (status/license/list-locations) — их прерывает вход
        self._mu = threading.Lock()
        self._inflight = {}           # одинаковые чтения не запускаем дважды
        self.askpass = None           # окно пароля для sudo (если нет правила без пароля)
        self._consent_fixed = False

    def env(self) -> dict:
        env = {k: v for k, v in os.environ.items() if k not in CLEAN_ENV_DROP}
        env.setdefault("HOME", home())
        path = env.get("PATH") or "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
        if "/usr/local/bin" not in path.split(":"):
            path = "/usr/local/bin:" + path
        env["PATH"] = path
        if self.askpass:
            env["SUDO_ASKPASS"] = self.askpass
        return env

    def run(self, args: list, timeout: float, cancel: threading.Event = None, out_path: str = None,
            progress=None, track: bool = True) -> dict:
        """
        `adguardvpn-cli <args>`: stdin=/dev/null, вывод — в файл, своя группа процессов.
        code: -1 тайм-аут, -2 нет CLI, -3 не запустился, -5 прервано (отмена/вход).
        """
        cli = find_cli()
        if not cli:
            return {"code": -2, "output": "Не найден adguardvpn-cli", "timeout": False, "error": "cli_not_found"}
        t0 = time.monotonic()
        try:
            out_f = open(out_path, "w+b") if out_path else tempfile.TemporaryFile(mode="w+b")
        except Exception as e:
            return {"code": -3, "output": f"Ошибка: {e}", "timeout": False}
        with out_f:
            try:
                proc = subprocess.Popen([cli] + list(args), stdin=subprocess.DEVNULL, stdout=out_f,
                                        stderr=subprocess.STDOUT, env=self.env(), cwd=home(),
                                        start_new_session=True, close_fds=True)
            except Exception as e:
                return {"code": -3, "output": f"Ошибка запуска: {e}", "timeout": False}
            if track:
                with self._mu:
                    self._procs.add(proc)
            timed_out = cancelled = False
            next_note = PROGRESS_EVERY
            try:
                while proc.poll() is None:
                    try:
                        proc.wait(timeout=0.25)
                    except subprocess.TimeoutExpired:
                        pass
                    if proc.poll() is not None:
                        break
                    el = time.monotonic() - t0
                    if cancel is not None and cancel.is_set():
                        cancelled = True
                        kill_group(proc)
                        break
                    if el >= timeout:
                        timed_out = True
                        kill_group(proc)
                        break
                    if progress and el >= next_note:
                        next_note += PROGRESS_EVERY
                        try:
                            out_f.flush()
                            progress(el, _file_tail(out_path) if out_path else "")
                        except Exception:
                            pass
            finally:
                if track:
                    with self._mu:
                        self._procs.discard(proc)
            out_f.flush()
            out_f.seek(0)
            text = strip_ansi(out_f.read(400_000).decode("utf-8", "replace")).strip()
        dt = time.monotonic() - t0
        if timed_out:
            LOG.error(f"adguardvpn-cli {' '.join(args)}: нет ответа за {timeout:.0f} сек. — остановлен")
            return {"code": -1, "output": (text + f"\nнет ответа за {timeout:.0f} сек.").strip(), "timeout": True}
        if cancelled or (proc.returncode in (-signal.SIGTERM, -signal.SIGKILL) and dt < timeout):
            return {"code": -5, "output": (text + "\nкоманда прервана").strip(), "timeout": False,
                    "error": "killed"}
        if dt > SLOW_CLI_SECONDS:
            LOG.warning(f"adguardvpn-cli {' '.join(args)}: ответ через {dt:.0f} сек. (медленная сеть?)")
        return {"code": proc.returncode, "output": text, "timeout": False, "seconds": round(dt, 1)}

    def run_checked(self, args: list, timeout: float) -> dict:
        """Чтение + один раз «нет» на вопросы первого запуска (как в плагине)."""
        r = self.run(args, timeout)
        if not r["timeout"] and r["code"] not in (0, -2, -5) and CONSENT_RE.search(r["output"]) \
                and not AUTH_RE.search(r["output"]):
            if not self._consent_fixed:
                self._consent_fixed = True
                fx = self.run(["config", "set-crash-reporting", "off"], timeout)
                LOG.info(f"первый запуск: set-crash-reporting off -> {fx['code']}")
                r = self.run(args, timeout)
            if CONSENT_RE.search(r["output"]) and not AUTH_RE.search(r["output"]):
                r["error"] = "not_configured"
        return r

    def once(self, args: list, timeout: float) -> dict:
        """Если такое же чтение уже идёт — ждём его результат, а не запускаем второй процесс."""
        key = " ".join(args)
        with self._mu:
            slot = self._inflight.get(key)
            owner = slot is None
            if owner:
                slot = {"done": threading.Event(), "res": None}
                self._inflight[key] = slot
        if not owner:
            slot["done"].wait(timeout + 30)
            return slot["res"] or {"code": -1, "output": "нет ответа", "timeout": True}
        try:
            slot["res"] = self.run_checked(args, timeout)
        except Exception as e:
            slot["res"] = {"code": -3, "output": f"Ошибка: {e}", "timeout": False}
        finally:
            with self._mu:
                self._inflight.pop(key, None)
            slot["done"].set()
        return slot["res"]

    def kill_reads(self, reason: str) -> int:
        with self._mu:
            procs = [p for p in self._procs if p.poll() is None]
        for p in procs:
            kill_group(p, 1.0)
        if procs:
            LOG.warning(f"прервано команд adguardvpn-cli: {len(procs)} ({reason})")
        return len(procs)


# =====================================================================================
#  sudo: правило без пароля (от установщика) или окно пароля (askpass)
# =====================================================================================

def sudo_nopasswd(cli: str = None) -> tuple:
    """(True|False|None, пояснение). None — sudo нет в системе."""
    if not shutil.which("sudo"):
        return None, "sudo не найден"
    last = ""
    tries = [["sudo", "-n", "true"]] + ([["sudo", "-n", "-l", cli]] if cli else [])
    for args in tries:
        try:
            r = subprocess.run(args, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                               text=True, errors="replace", timeout=15, start_new_session=True)
            if r.returncode == 0:
                return True, ""
            last = strip_ansi(r.stdout).strip()[:160]
        except Exception as e:
            last = str(e)
    return False, last


def write_askpass() -> str:
    """Скрипт «окно пароля» для sudo: само приложение показывает поле ввода (Qt)."""
    path = os.path.join(_ensure(state_dir()), "askpass.sh")
    pkg_parent = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    body = ("#!/bin/sh\n# Окно пароля администратора для sudo (AdGuard VPN для рабочего стола)\n"
            f"PYTHONPATH='{pkg_parent}' exec '{sys.executable}' -m adguard_vpn_desktop --askpass \"$@\"\n")
    try:
        old = open(path, encoding="utf-8").read() if os.path.exists(path) else ""
        if old != body:
            with open(path + ".tmp", "w", encoding="utf-8") as f:
                f.write(body)
            os.chmod(path + ".tmp", 0o700)
            os.replace(path + ".tmp", path)
    except Exception as e:
        LOG.warning(f"askpass: {e}")
    return path


# =====================================================================================
#  IP и обновления
# =====================================================================================

def http_json(url: str, timeout: int = 12):
    req = urllib.request.Request(url, headers={"User-Agent": f"adguard-vpn-desktop/{VERSION}",
                                               "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read(200_000).decode("utf-8", "replace"))


def fetch_ip() -> dict:
    """Внешний IP и страна. Запрос идёт с компьютера, т.е. через VPN, если он включён."""
    fake = os.environ.get("ADGUARD_VPN_DESKTOP_FAKE_IP")          # только для тестов без сети
    if fake:
        ip, _, cc = fake.partition(",")
        return {"ok": True, "ip": ip, "country": cc, "city": "", "source": "test"}
    errors = []
    for url, conv in (
        ("https://ipinfo.io/json", lambda d: (d.get("ip"), d.get("country"), d.get("city"))),
        ("https://ipwho.is/", lambda d: (d.get("ip"), d.get("country_code"), d.get("city"))
            if d.get("success", True) else (None, None, None)),
        ("https://api.country.is/", lambda d: (d.get("ip"), d.get("country"), "")),
    ):
        try:
            ip, cc, city = conv(http_json(url, 8))
            if ip:
                return {"ok": True, "ip": ip, "country": (cc or "").upper()[:2], "city": city or "",
                        "source": url.split("/")[2]}
        except Exception as e:
            errors.append(f"{url.split('/')[2]}: {e}")
    return {"ok": False, "error": "; ".join(errors)[:300]}


def net_ok() -> bool:
    if os.environ.get("ADGUARD_VPN_DESKTOP_FAKE_IP"):
        return True
    import socket
    for host in ("api.github.com", "ipinfo.io", "1.1.1.1"):
        try:
            socket.create_connection((host, 443), timeout=5).close()
            return True
        except Exception:
            continue
    return False


# =====================================================================================
#  Настройки, состояние, общий маркер, избранное, автозапуск
# =====================================================================================

DEFAULT_SETTINGS = {
    "autoconnect": False,           # подключаться при запуске приложения
    "autoconnect_action": "last",   # last | fastest | Slovakia… | loc:<локация>
    "autoconnect_label": "",
    "reconnect": False,             # сторож: переподключать при обрыве
    "start_minimized": False,       # запускаться свёрнутым в трей
    "notifications": True,
}


def load_settings() -> dict:
    raw = read_json(os.path.join(config_dir(), "settings.json"))
    out = dict(DEFAULT_SETTINGS)
    for k, v in raw.items():
        if k in out and isinstance(v, type(out[k])):
            out[k] = v
    return out


def save_settings(cfg: dict) -> None:
    write_json(os.path.join(config_dir(), "settings.json"), cfg)


def load_state() -> dict:
    return read_json(os.path.join(state_dir(), "state.json"))


def save_state(**kw) -> None:
    st = load_state()
    st.update(kw, ts=time.strftime("%Y-%m-%d %H:%M:%S"))
    try:
        write_json(os.path.join(state_dir(), "state.json"), st)
    except Exception as e:
        LOG.warning(f"state.json: {e}")


def desired_path() -> str:
    return os.path.join(shared_dir(), "desired.json")


def write_desired(desired: str, action: str = "", label: str = "", by: str = "desktop") -> None:
    """Общий маркер «что хотел пользователь» (читают приложение и плагин 1.1.2+)."""
    try:
        write_json(desired_path(), {"desired": desired, "action": action, "label": label, "by": by,
                                    "ts": time.time(), "time": time.strftime("%Y-%m-%d %H:%M:%S")})
    except Exception as e:
        LOG.warning(f"desired.json: {e}")


def effective_desired() -> dict:
    """
    Последнее решение пользователя — из приложения или плагина (кто позже).
    Источники: общий desired.json и state.json плагина (~/homebrew/settings/adguard-vpn).
    """
    best = {"desired": "", "action": "", "label": "", "by": "", "ts": 0.0}
    d = read_json(desired_path())
    if d.get("desired") in ("connected", "disconnected"):
        try:
            ts = float(d.get("ts") or 0)
        except (TypeError, ValueError):
            ts = 0.0
        best = {"desired": d["desired"], "action": d.get("action", ""), "label": d.get("label", ""),
                "by": d.get("by", "?"), "ts": ts}
    pst_path = os.path.join(plugin_settings_dir(), "state.json")
    pst = read_json(pst_path) if os.path.exists(pst_path) else {}
    if pst.get("desired") in ("connected", "disconnected"):
        try:
            ts = time.mktime(time.strptime(pst.get("ts", ""), "%Y-%m-%d %H:%M:%S"))
        except Exception:
            try:
                ts = os.path.getmtime(pst_path)
            except OSError:
                ts = 0.0
        if ts > best["ts"]:
            best = {"desired": pst["desired"], "action": pst.get("last_action", ""),
                    "label": pst.get("last_label", ""), "by": "plugin", "ts": ts}
    return best


def favorites_paths() -> list:
    """Файл плагина (если плагин установлен) и свой. Свой — всегда последний."""
    own = os.path.join(config_dir(), "favorites.json")
    if os.path.isdir(os.path.join(home(), "homebrew")):
        return [os.path.join(plugin_settings_dir(), "favorites.json"), own]
    return [own]


def load_favorites() -> list:
    """Берём самый свежий из существующих файлов (плагин или приложение — кто менял последним)."""
    existing = [p for p in favorites_paths() if os.path.exists(p)]
    existing.sort(key=lambda p: os.path.getmtime(p), reverse=True)
    for p in existing:
        v = read_json(p).get("favorites")
        if isinstance(v, list):
            return [k for k in v if isinstance(k, str)]
    return []


def save_favorites(favs: list) -> list:
    """Пишем в свой файл и в файл плагина, если он доступен на запись (у плагина он может быть root)."""
    paths = favorites_paths()
    own = paths[-1]
    written = []
    for p in paths:
        if p != own:
            d = os.path.dirname(p)
            can = os.access(p, os.W_OK) if os.path.exists(p) else (os.path.isdir(d) and os.access(d, os.W_OK))
            if not can:
                continue
        try:
            write_json(p, {"favorites": favs})
            written.append(p)
        except Exception as e:
            LOG.warning(f"{p}: {e}")
    return written


def launcher_cmd() -> str:
    env = os.environ.get("ADGUARD_VPN_DESKTOP_LAUNCHER")
    if env and os.path.exists(env):
        return env
    p = os.path.join(home(), ".local/bin/adguard-vpn-desktop")
    if os.path.exists(p):
        return p
    pkg_parent = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return f"env PYTHONPATH={pkg_parent} {sys.executable} -m adguard_vpn_desktop"


def autostart_enabled() -> bool:
    p = autostart_path()
    if not os.path.exists(p):
        return False
    try:
        return "Hidden=true" not in open(p, encoding="utf-8").read()
    except Exception:
        return False


def set_autostart(on: bool) -> None:
    p = autostart_path()
    if not on:
        try:
            os.remove(p)
        except FileNotFoundError:
            pass
        return
    _ensure(os.path.dirname(p))
    with open(p, "w", encoding="utf-8") as f:
        f.write("[Desktop Entry]\nType=Application\nName=AdGuard VPN\n"
                "Comment=AdGuard VPN — запуск вместе с рабочим столом (свёрнуто в трей)\n"
                f"Exec={launcher_cmd()} --minimized\nIcon=adguard-vpn-desktop\nTerminal=false\n"
                "X-GNOME-Autostart-enabled=true\nX-KDE-autostart-after=panel\n")


# =====================================================================================
#  Вход в аккаунт (adguardvpn-cli login в псевдотерминале — иначе CLI не отдаёт ссылку сразу)
# =====================================================================================

def _no_echo(fd: int) -> None:
    try:
        import termios                       # может не быть — тогда stty
        attrs = termios.tcgetattr(fd)
        attrs[3] &= ~termios.ECHO
        termios.tcsetattr(fd, termios.TCSANOW, attrs)
        return
    except Exception:
        pass
    try:
        subprocess.run(["stty", "-echo"], stdin=fd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=3)
    except Exception:
        pass


class LoginSession:
    def __init__(self, runner: CliRunner, events: Events):
        self.runner, self.events = runner, events
        self.proc = None
        self.fd = None
        self.started = 0.0
        self.answered = False
        self.logged = True
        self.log_path = os.path.join(state_dir(), "login.log")

    def running(self) -> bool:
        return bool(self.proc and self.proc.poll() is None)

    def _pump(self, fd: int) -> None:
        try:
            with open(self.log_path, "ab", buffering=0) as lf:
                while True:
                    try:
                        chunk = os.read(fd, 4096)
                    except OSError:                 # EIO — процесс закрыл терминал
                        break
                    if not chunk:
                        break
                    lf.write(chunk.replace(b"\r\n", b"\n"))
        finally:
            try:
                os.close(fd)
            except OSError:
                pass
            if self.fd == fd:
                self.fd = None

    def write(self, data: bytes) -> None:
        if self.fd is None:
            raise OSError("вход не запущен")
        os.write(self.fd, data)

    def start(self) -> dict:
        cli = find_cli()
        if not cli:
            self.events.add("error", "Ошибка: adguardvpn-cli не установлен", "")
            return {"ok": False, "message": "adguardvpn-cli не найден. Запустите установщик."}
        if self.running():
            return self.poll()
        _ensure(state_dir())
        with open(self.log_path, "w", encoding="utf-8") as lf:
            lf.write(f"=== {time.strftime('%Y-%m-%d %H:%M:%S')} adguardvpn-cli login\n")
        master, slave = os.openpty()
        _no_echo(slave)
        env = self.runner.env()
        env["TERM"] = "dumb"
        try:
            self.proc = subprocess.Popen([cli, "login"], stdin=slave, stdout=slave, stderr=slave, env=env,
                                         cwd=home(), start_new_session=True, close_fds=True)
        except Exception as e:
            os.close(master)
            os.close(slave)
            return {"ok": False, "message": f"Не удалось запустить вход: {e}"}
        os.close(slave)
        self.fd = master
        threading.Thread(target=self._pump, args=(master,), daemon=True).start()
        threading.Thread(target=self.proc.wait, daemon=True).start()
        self.started = time.monotonic()
        self.answered = False
        self.logged = False
        for _ in range(30):                     # до 15 сек. ждём ссылку, дальше окно опрашивает само
            time.sleep(0.5)
            st = self.poll()
            if st.get("url") or st.get("done") or not st.get("running"):
                return st
        return self.poll()

    def poll(self) -> dict:
        try:
            text = strip_ansi(open(self.log_path, encoding="utf-8", errors="replace").read())
        except Exception:
            text = ""
        body = "\n".join(text.splitlines()[1:]).strip()
        running = self.running()
        if running and not self.answered and body and CONSENT_RE.search(body.splitlines()[-1]) \
                and not LOGIN_URL_RE.search(body):
            try:
                self.write(b"n\n")
                self.answered = True
            except Exception:
                pass
        url = extract_login_url(body)
        cm = LOGIN_CODE_RE.search(body)
        code = (cm.group(1) or cm.group(2)) if cm else ""
        tm = LOGIN_TTL_RE.search(body)
        ttl = int(tm.group(1)) if tm else 0
        left = max(0, int(ttl - (time.monotonic() - self.started))) if ttl else 0
        success = bool(LOGIN_OK_RE.search(body))
        fail = None
        if not running and not success and self.proc is not None:
            fm = LOGIN_FAIL_RE.search(body)
            fail = fm.group(1).strip() if fm else f"вход завершился (код {self.proc.returncode})"
        if (success or fail) and not self.logged:
            self.logged = True
            if success:
                self.events.add("ok", "Вход выполнен", body[-1500:])
            else:
                self.events.add("error", "Ошибка: вход не выполнен", f"{fail}\n{body[-1500:]}")
        return {"ok": True, "running": running, "url": url, "code": code, "seconds_left": left,
                "done": success, "error": fail, "output": body[-1500:]}

    def speedup(self) -> dict:
        if self.running():
            try:
                self.write(b"s\n")               # пункт меню CLI «s - Speed up check»
            except Exception:
                pass
        time.sleep(2)
        return self.poll()

    def cancel(self) -> dict:
        p = self.proc
        if p and p.poll() is None:
            try:
                self.write(b"x\n")               # пункт меню CLI «x - Cancel»
            except Exception:
                pass
            for _ in range(6):
                if p.poll() is not None:
                    break
                time.sleep(0.25)
            if p.poll() is None:
                kill_group(p, 1.0)
        if not self.logged:
            self.logged = True
            self.events.add("info", "Вход отменён", "")
        return {"ok": True, "message": "Вход отменён"}


# =====================================================================================
#  Backend — всё, что делает окно (вызывать ТОЛЬКО из фоновых потоков)
# =====================================================================================

ACTION_NAMES = {"fastest": "Самая быстрая", "off": "Отключить"}


class Backend:
    def __init__(self, notify=None):
        _ensure(state_dir())
        _ensure(config_dir())
        self.events = Events()
        self.cli = CliRunner(self.events)
        self.login = LoginSession(self.cli, self.events)
        self.lock = SharedLock()
        self.action_mu = threading.Lock()
        self.cur = {}
        self.auth = None
        self.wd = {"fails": 0, "next": 0.0}
        self.notify = notify or (lambda title, body: None)
        self._ping = {"ts": 0.0, "data": None}
        self._ping_mu = threading.Lock()
        self._ip = {"ts": 0.0, "data": None}
        self._update = {"ts": 0.0, "data": None}
        self._sudo = {"ts": 0.0, "ok": None, "how": ""}
        self._status_err = ""
        self._stop = threading.Event()

    # ---------- служебное ----------

    def who(self) -> str:
        cfg = os.path.join(home(), ".local/share/adguardvpn-cli")
        return (f"пользователь: {os.environ.get('USER') or '?'} (uid {os.getuid()})\nHOME: {home()}\n"
                f"настройки CLI: {cfg} ({'есть' if os.path.isdir(cfg) else 'НЕТ'})\n"
                f"CLI: {find_cli() or 'не найден'}\nзамок: {self.lock.path}")

    def sudo_state(self, force: bool = False) -> dict:
        s = self._sudo
        if force or s["ts"] == 0.0 or time.monotonic() - s["ts"] > SUDO_CACHE_SECONDS:
            ok, how = sudo_nopasswd(find_cli())
            s.update(ts=time.monotonic(), ok=ok, how=how)
            # Нет правила «без пароля» → sudo внутри CLI покажет наше окно пароля (SUDO_ASKPASS)
            self.cli.askpass = None if ok else write_askpass()
        return {"nopasswd": s["ok"], "how": s["how"], "askpass": self.cli.askpass}

    # ---------- статус (только чтение, никогда не ждёт действий) ----------

    def get_status(self) -> dict:
        def bad(raw, code, error):
            return {"state": "unknown", "connected": False, "location": None, "location_text": "",
                    "raw": raw, "code": code, "error": error, "busy": self.busy()}
        if not find_cli():
            return bad("Не найден adguardvpn-cli", -2, "cli_not_found")
        r = self.cli.once(["status"], STATUS_TIMEOUT)
        if r["timeout"] and self._status_err != "timeout":
            self.events.add("warn", "Ошибка: тайм-аут AdGuard (status)", f"нет ответа за {STATUS_TIMEOUT} сек.")
        self._status_err = "timeout" if r["timeout"] else ""
        if r["timeout"]:
            return bad(f"status не ответил за {STATUS_TIMEOUT} сек. Обычно это медленная сеть.", -1, "timeout")
        if r.get("error") == "killed":
            return bad(r["output"], -5, "killed")
        if r["code"] == -3:
            return bad(r["output"], -3, "spawn_failed")
        if r.get("error") == "not_configured":
            return bad(r["output"], r["code"], "not_configured")
        st = parse_status(r["output"], r["code"])
        if st["error"] == "not_logged_in":
            self.auth = False
        if r.get("seconds", 0) > SLOW_CLI_SECONDS:
            st["slow"] = r["seconds"]
        st["busy"] = self.busy()
        return st

    def busy(self) -> dict:
        c = self.cur
        if not c:
            return {}
        return {"name": c.get("name", ""), "action": c.get("action", ""),
                "seconds": int(time.monotonic() - c.get("started", time.monotonic())),
                "waiting_lock": bool(c.get("waiting_lock"))}

    # ---------- действия ----------

    @staticmethod
    def action_args(action: str):
        if action == "off":
            return ["disconnect"]
        if action == "fastest":
            return ["connect", "-f", "-y"]
        if action in FIXED_IDS:
            return ["connect", "-l", action, "-y"]
        t = location_target(action)
        if t:
            return ["connect", "-l", t, "-y"]
        return None

    def run_action(self, action: str, label: str = "", source: str = "user") -> dict:
        """Кнопка в окне/трее. «Отключить» во время подключения — сначала отменяет подключение."""
        if action == "off" and self.cur:
            self.cancel_action("нажато «Отключить»")
        return self.do_action(action, label, source)

    def cancel_action(self, why: str) -> int:
        c = self.cur
        ev = c.get("cancel")
        if not ev:
            return 0
        c["cancelled"] = why
        ev.set()
        self.events.add("warn", f"Отменено: {c.get('name') or 'действие'}", f"причина: {why}")
        return 1

    def do_action(self, action: str, label: str = "", source: str = "user") -> dict:
        action = (action or "").strip()
        args = self.action_args(action)
        who = {"watchdog": " (сторож)", "autoconnect": " (автозапуск)", "tray": " (трей)"}.get(source, "")
        name = label or ACTION_NAMES.get(action) or action.replace("loc:", "")
        if args is None:
            return {"ok": False, "message": f"Неизвестное действие: {action[:40]!r}"}
        if action != "off":
            self.events.add("info", f"▶ Подключение: {name}{who}", f"действие: {action}\n{self.who()}")
        if self.action_mu.locked():
            self.events.add("info", f"Ждёт очереди: {name}{who}", "идёт другое действие")
        cancel = threading.Event()
        with self.action_mu:
            self.cur = {"name": name, "action": action, "cancel": cancel, "started": time.monotonic()}
            try:
                res = self._action_impl(action, args, source, cancel)
            except Exception as e:
                LOG.exception("action")
                res = {"ok": False, "message": f"Ошибка приложения: {e}"}
            finally:
                cancelled = self.cur.get("cancelled")
                self.cur = {}
        return self._after_action(action, label, source, res, cancelled, who)

    def _action_impl(self, action: str, args: list, source: str, cancel: threading.Event) -> dict:
        self.sudo_state()
        t0 = time.monotonic()
        if self.lock.held_by_other():
            self.cur["waiting_lock"] = True
            self.events.add("info", "Ждёт: AdGuard занят другой программой (плагин?)", self.lock.path)
        if not self.lock.acquire(LOCK_WAIT, cancel):
            self.cur["waiting_lock"] = False
            if cancel.is_set():
                return {"ok": False, "message": "Отменено", "cancelled": True}
            return {"ok": False, "message": f"AdGuard занят другой программой дольше {LOCK_WAIT} с",
                    "error_label": "Ошибка: AdGuard занят (плагин?)"}
        self.cur["waiting_lock"] = False
        try:
            if time.monotonic() - t0 > 2:
                self.events.add("info", f"Дождался очереди ({int(time.monotonic() - t0)} с)", "")
            if source in ("watchdog", "autoconnect") and action != "off":
                # плагин мог уже подключить, пока мы ждали замок — не переподключаем зря
                r0 = self.cli.run(["status"], STATUS_TIMEOUT, cancel)
                st0 = parse_status(r0["output"], r0["code"])
                if st0["connected"]:
                    return {"ok": True, "message": "Уже подключено", "status": st0, "already": True}
                if cancel.is_set():
                    return {"ok": False, "message": "Отменено", "cancelled": True}
            log_path = os.path.join(state_dir(), "connect.log")

            def progress(el, tail):
                self.events.add("warn" if el >= ACTION_SOFT_TIMEOUT else "info",
                                f"{args[0]} идёт {int(el)} с…", tail or "вывода пока нет")
            r = self.cli.run(args, ACTION_HARD_TIMEOUT, cancel=cancel, out_path=log_path, progress=progress,
                             track=False)
            body = r["output"]
            if r["timeout"]:
                self.events.add("error", f"Тайм-аут {ACTION_HARD_TIMEOUT} с — остановлено", body[-800:])
                return {"ok": False, "message": f"AdGuard не ответил за {ACTION_HARD_TIMEOUT} с — остановлено",
                        "output": body, "code": -1, "error_label": "Ошибка: тайм-аут AdGuard"}
            if r.get("error") == "killed" or cancel.is_set():
                return {"ok": False, "message": "Отменено", "output": body, "code": -5, "cancelled": True}
            if r["code"] in (-2, -3):
                return {"ok": False, "message": r["output"], "output": body, "code": r["code"]}
            res = self._result(r["code"], body, action)
            res["code"] = r["code"]
            cancel.wait(1.0 if action == "off" else 1.5)
            sr = self.cli.run(["status"], STATUS_TIMEOUT, cancel)
            if not sr["timeout"] and sr["code"] != -5:
                st = parse_status(sr["output"], sr["code"])
                res["status"] = st
                if action == "off" and st["state"] == "disconnected":
                    res.update(ok=True, message="VPN отключён")
                if res["ok"] and action != "off" and st["state"] == "disconnected":
                    res["warning"] = "CLI сообщил об успехе, но status показывает «отключено»"
            return res
        finally:
            self.lock.release()

    @staticmethod
    def _result(code: int, body: str, action: str) -> dict:
        ok_conn = re.search(r"successfully connected to\s+([^\r\n.]+)", body, re.IGNORECASE)
        if ok_conn:
            msg = f"Подключено: {ok_conn.group(1).strip()}"
            if "dns could not be configured" in body.lower():
                msg += " (системный DNS не настроен)"
            return {"ok": True, "message": msg, "output": body}
        if action == "off" and re.search(r"disconnected|stopped|not running", body, re.I):
            return {"ok": True, "message": "VPN отключён", "output": body}
        if code == 0:
            return {"ok": True, "message": "Готово", "output": body}
        last = body.splitlines()[-1] if body else f"код {code}"
        return {"ok": False, "message": f"AdGuard: {last[:160]}", "output": body}

    def _after_action(self, action, label, source, res, cancelled, who) -> dict:
        if cancelled and not res.get("ok"):
            res.update(message=f"Отменено ({cancelled})", cancelled=True)
        self._ip["ts"] = 0.0
        if source != "watchdog":
            self.wd.update(fails=0, next=0.0)
        st = res.get("status") or {}
        if res.get("ok") and action == "off":
            save_state(desired="disconnected")
            write_desired("disconnected")
        elif res.get("ok"):
            if source in ("user", "tray") or st.get("connected"):
                last = action
                loc = (st.get("location_text") or "").strip()
                if action == "fastest" and loc and location_target("loc:" + loc.title()):
                    last = "loc:" + loc.title()
                upd = {"desired": "connected", "gave_up": False}
                if source in ("user", "tray"):
                    upd.update(last_action=last, last_label=label or loc.title() or action)
                save_state(**upd)
                write_desired("connected", last, label or loc.title())
        if AUTH_RE.search(f"{res.get('output', '')}") and not res.get("ok") and not res.get("cancelled"):
            self.auth = False
            res["message"] = "Не выполнен вход в AdGuard — нажмите «🔑 Войти»"
        name = label or (st.get("location_text") or "").title() or ACTION_NAMES.get(action) \
            or action.replace("loc:", "")
        details = f"действие: {action}\nкод: {res.get('code', '—')}\n{res.get('output', '')}".strip()
        if st.get("raw"):
            details += f"\n\nstatus:\n{st['raw']}"
        if res.get("cancelled"):
            res["error_label"] = "Отменено"
        elif not res.get("ok"):
            lab = res.get("error_label") or explain_error(f"{res.get('message', '')}\n{res.get('output', '')}")
            if lab == SUDO_LABEL:
                res["message"] = ("Нет прав администратора: пароль не введён или неверный. "
                                  "Чтобы не вводить его каждый раз — запустите установщик ещё раз.")
            res["error_label"] = lab
            self.events.add("error", f"{lab}{who}", f"{res.get('message', '')}\n{details}")
        elif res.get("already"):
            self.events.add("info", f"Уже подключено{who}", details)
        elif action == "off":
            self.events.add("info", "VPN отключён" + who, details)
        elif res.get("warning"):
            self.events.add("warn", f"{name}: CLI «успех», но статус «отключено»{who}", details)
        else:
            verb = "Переподключено" if source == "watchdog" else "Подключено"
            self.events.add("ok", f"{verb}: {name}{who}", details)
        LOG.info(f"action[{source}] {action!r} -> ok={res.get('ok')} {res.get('message')!r}")
        return res

    # ---------- пинг и локации ----------

    def get_locations(self, force: bool = False) -> dict:
        """Все локации аккаунта из `list-locations` (кеш 45 сек.). Нет CLI — встроенный список без пинга."""
        with self._ping_mu:
            c = self._ping
            if force or c["data"] is None or time.monotonic() - c["ts"] >= PING_CACHE_SECONDS:
                r = self.cli.once(["list-locations"], PING_TIMEOUT)
                out = r["output"]
                if r["code"] == -2:
                    data = {"rows": [], "error": "cli_not_found"}
                elif r["timeout"]:
                    data = {"rows": [], "error": "timeout"}
                elif r.get("error"):
                    data = {"rows": [], "error": r["error"]}
                elif AUTH_RE.search(out):
                    data = {"rows": [], "error": "not_logged_in"}
                else:
                    rows = parse_locations(out)
                    data = {"rows": rows, "error": None if rows else "no_data"}
                    if not rows:
                        LOG.warning(f"list-locations: не удалось разобрать вывод: {out[:300]!r}")
                if data["rows"] or c["data"] is None or not c["data"]["rows"]:
                    c.update(ts=time.monotonic(), data=data)     # при сбое оставляем прошлый удачный список
                else:
                    c["ts"] = time.monotonic() - PING_CACHE_SECONDS + 15
            data, age = c["data"], int(time.monotonic() - c["ts"])
        if data["rows"]:
            return {"ok": True, "source": "cli", "locations": data["rows"], "error": None, "age": age}
        return {"ok": False, "source": "fallback", "locations": fallback_locations(), "error": data["error"],
                "age": age}

    # ---------- избранное ----------

    def get_favorites(self) -> list:
        return load_favorites()

    def set_favorite(self, key: str, on: bool) -> list:
        favs = [k for k in load_favorites() if k != key]
        if on and isinstance(key, str) and 0 < len(key) <= 100:
            favs.append(key)
        save_favorites(favs)
        return favs

    # ---------- аккаунт ----------

    def account_info(self) -> dict:
        r = self.cli.once(["license"], STATUS_TIMEOUT)
        out = r["output"]
        if r["code"] == -2:
            return {"cli": False, "logged_in": False, "raw": out}
        if r["timeout"] or r.get("error"):
            return {"cli": True, "logged_in": None, "raw": out, "error": r.get("error") or "timeout"}
        logged_in = None
        if AUTH_RE.search(out):
            logged_in = False
        elif r["code"] == 0 and out:
            logged_in = True
        if logged_in is not None:
            self.auth = logged_in
        lic = parse_license(out) if logged_in else {}
        return dict(lic, cli=True, logged_in=logged_in, raw=out, code=r["code"],
                    no_subscription=bool(LICENSE_RE.search(out)))

    def login_start(self) -> dict:
        if self.login.running():
            return self.login.poll()
        self.events.add("info", "Вход: запуск", self.who())
        # Вход важнее всего: отменяем подключение и зависшие status/license
        if self.cur:
            self.cancel_action("нажато «Войти»")
        n = self.cli.kill_reads("вход")
        if n:
            self.events.add("info", f"Вход: прервано команд AdGuard: {n}", "status/license/list-locations")
        # короткая пауза, если плагин как раз что-то делает с AdGuard (замок весь вход не держим)
        if self.lock.acquire(10):
            self.lock.release()
        res = self.login.start()
        if res.get("done"):
            self.auth = True
            self.wd.update(fails=0, next=0.0)
        return res

    def login_speedup(self) -> dict:
        res = self.login.speedup()
        if res.get("done"):
            self.auth = True
            self._ping["ts"] = 0.0
        return res

    def login_cancel(self) -> dict:
        return self.login.cancel()

    def login_poll(self) -> dict:
        res = self.login.poll()
        if res.get("done"):
            self.auth = True
            self._ping["ts"] = 0.0
        return res

    def logout(self) -> dict:
        got = self.lock.acquire(30)
        try:
            r = self.cli.run(["logout"], STATUS_TIMEOUT)
        finally:
            if got:
                self.lock.release()
        ok = r["code"] == 0 or "logged out" in r["output"].lower()
        self.events.add("info" if ok else "error", "Выход из аккаунта" if ok else "Ошибка: выход не выполнен",
                        f"код: {r['code']}\n{r['output']}")
        if ok:
            self.auth = False
        return {"ok": ok, "message": "Вы вышли из аккаунта AdGuard" if ok else f"Не удалось выйти: {r['output'][:160]}"}

    # ---------- проверка установки ----------

    def check_setup(self) -> dict:
        items = []

        def add(id_, ok, label, hint="", required=True):
            items.append({"id": id_, "ok": bool(ok), "label": label, "hint": hint, "required": required})
        cli = find_cli()
        add("cli", bool(cli), "Не установлена программа adguardvpn-cli",
            "запустите установщик: bash install-adguard-vpn-desktop.sh")
        if cli:
            r = self.cli.once(["license"], STATUS_TIMEOUT)
            responds = not r["timeout"] and r["code"] not in (-1, -3, -5) and r.get("error") != "not_configured"
            add("cli_responds", responds, "adguardvpn-cli не отвечает",
                "" if responds else ("нет ответа — медленная сеть?" if r["timeout"] else r["output"][:120]))
        s = self.sudo_state(force=True)
        add("sudo", s["nopasswd"] is not False, "Пароль администратора будет спрашиваться окном при подключении",
            "чтобы не спрашивал — запустите установщик и согласитесь на правило sudo", required=False)
        failed = [i for i in items if i["required"] and not i["ok"]]
        return {"ok": not failed, "items": items, "missing": failed}

    # ---------- настройки ----------

    def get_settings(self) -> dict:
        st = load_state()
        return dict(load_settings(), last_action=st.get("last_action", ""), last_label=st.get("last_label", ""),
                    autostart=autostart_enabled(), version=VERSION)

    def set_settings(self, changes: dict) -> dict:
        cur = load_settings()
        for k, v in (changes or {}).items():
            if k == "autostart":
                set_autostart(bool(v))
                self.events.add("info", "Автозапуск с рабочим столом: " + ("включён" if v else "выключен"),
                                autostart_path())
                continue
            if k in DEFAULT_SETTINGS and isinstance(v, type(DEFAULT_SETTINGS[k])):
                if k == "autoconnect_action" and v not in ("last", "fastest") and v not in FIXED_IDS \
                        and not location_target(v):
                    continue
                cur[k] = v[:80] if isinstance(v, str) else v
        save_settings(cur)
        if cur["reconnect"]:
            save_state(gave_up=False)
            self.wd.update(fails=0, next=0.0)
        return self.get_settings()

    # ---------- сторож: переподключение при обрыве ----------

    def watchdog_tick(self) -> str:
        """Одна проверка. Возвращает, что сделано (для журнала и тестов)."""
        cfg = load_settings()
        if not cfg["reconnect"]:
            self.wd.update(fails=0, next=0.0)
            return "off"
        st = load_state()
        want = effective_desired()
        if want["desired"] != "connected":
            return "idle"       # последним пользователь нажал «Отключить» (здесь или в плагине) — не трогаем
        action = want["action"] or st.get("last_action", "")
        label = want["label"] or st.get("last_label", "")
        if not action or st.get("gave_up"):
            return "idle"
        if self.action_mu.locked():
            return "busy"
        if self.login.running():
            return "login"
        if time.monotonic() < self.wd["next"]:
            return "wait"
        r = self.cli.once(["status"], STATUS_TIMEOUT)
        if r["timeout"] or r.get("error") or r["code"] < 0:
            return "unknown"
        status = parse_status(r["output"], r["code"])
        if status.get("error") or status["state"] != "disconnected":
            if status.get("connected"):
                self.wd.update(fails=0, next=0.0)
            return status["state"] if not status.get("error") else status["error"]
        n = self.wd["fails"]
        if n >= len(RECONNECT_DELAYS):
            save_state(gave_up=True)
            self.notify("❌ VPN не восстановлен", "См. Журнал")
            self.events.add("error", "Сторож: VPN не восстановлен (3 попытки)", f"локация: {action}")
            return "gave_up"
        if self.wd["next"] == 0.0:
            self.wd["next"] = time.monotonic() + RECONNECT_DELAYS[n]
            if n == 0:
                self.events.add("warn", "Обрыв VPN — переподключаю", f"status:\n{r['output']}")
            return "scheduled"
        # перед самой попыткой ещё раз: не нажал ли пользователь «Отключить» в плагине за эти секунды
        if effective_desired()["desired"] != "connected":
            self.wd.update(fails=0, next=0.0)
            return "idle"
        if self.auth is False:
            save_state(gave_up=True)
            self.events.add("warn", "Сторож: не выполнен вход — переподключение выключено", "войдите в AdGuard")
            return "not_logged_in"
        self.wd["fails"] = n + 1
        res = self.do_action(action, label, source="watchdog")
        ok = bool(res.get("ok")) and (res.get("status") or {}).get("state") != "disconnected"
        if not ok and (self.auth is False or res.get("error_label") == SUDO_LABEL or res.get("cancelled")):
            save_state(gave_up=True)
            self.wd.update(fails=0, next=0.0)
            self.events.add("error", "Сторож остановлен: " + ("отмена" if res.get("cancelled") else
                            "нет входа" if self.auth is False else "нет прав sudo"), res.get("message", ""))
            self.notify("❌ Переподключение", "См. Журнал")
            return "stopped"
        if ok:
            self.wd.update(fails=0, next=0.0)
            if not res.get("already"):
                self.notify("🔄 VPN переподключён", (label or action)[:40])
            return "reconnected"
        nxt = self.wd["fails"]
        self.wd["next"] = time.monotonic() + (RECONNECT_DELAYS[nxt] if nxt < len(RECONNECT_DELAYS) else 0)
        return "retry_failed"

    def _watchdog_loop(self):
        if self._stop.wait(WATCHDOG_INTERVAL):
            return
        while not self._stop.is_set():
            try:
                what = self.watchdog_tick()
                if what not in ("off", "idle", "connected", "wait"):
                    LOG.info(f"watchdog: {what}")
            except Exception:
                LOG.exception("watchdog")
            self._stop.wait(WATCHDOG_INTERVAL if self.wd["next"] == 0.0 else 5)

    # ---------- автоподключение при запуске ----------

    def autoconnect(self, delay: float = AUTOCONNECT_DELAY, wait: float = AUTOCONNECT_WAIT) -> str:
        cfg = load_settings()
        if not cfg["autoconnect"]:
            return "off"
        self.events.add("info", f"Автоподключение через {int(delay)} с",
                        f"локация: {cfg['autoconnect_label'] or cfg['autoconnect_action']}")
        if self._stop.wait(delay):
            return "stopped"
        deadline = time.monotonic() + wait
        while not net_ok():
            if time.monotonic() >= deadline or self._stop.wait(10):
                self.events.add("error", "Автоподключение: нет сети", f"ждали {int(wait)} сек.")
                return "no_network"
        action, label = cfg["autoconnect_action"], cfg["autoconnect_label"]
        if action == "last":
            want, st = effective_desired(), load_state()
            action = want["action"] or st.get("last_action", "")
            label = want["label"] or st.get("last_label", "")
        if not action:
            self.events.add("info", "Автоподключение: локация не выбрана", "")
            return "no_location"
        lic = self.cli.once(["license"], STATUS_TIMEOUT)
        if not lic["timeout"] and AUTH_RE.search(lic["output"]):
            self.auth = False
            self.events.add("warn", "Автоподключение пропущено: не выполнен вход", lic["output"][:500])
            self.notify("🔑 AdGuard: нужен вход", "Автоподключение пропущено")
            return "not_logged_in"
        if self.login.running():
            self.events.add("info", "Автоподключение пропущено: идёт вход", "")
            return "login"
        r = self.cli.once(["status"], STATUS_TIMEOUT)
        if not r["timeout"] and parse_status(r["output"], r["code"]).get("connected"):
            self.events.add("info", "Автоподключение: VPN уже включён", "")
            return "already_connected"
        res = self.do_action(action, label, source="autoconnect")
        if res.get("ok"):
            save_state(desired="connected", gave_up=False)
            if not res.get("already"):
                self.notify("✅ Автоподключение", (label or action)[:40])
            return "connected"
        self.notify("❌ Автоподключение", "См. Журнал")
        return "failed"

    def start_background(self) -> None:
        threading.Thread(target=self._watchdog_loop, name="watchdog", daemon=True).start()
        threading.Thread(target=self._autoconnect_safe, name="autoconnect", daemon=True).start()

    def _autoconnect_safe(self):
        try:
            self.autoconnect()
        except Exception as e:
            LOG.exception("autoconnect")
            self.events.add("error", "Автоподключение: ошибка приложения", f"{type(e).__name__}: {e}")

    def stop(self) -> None:
        self._stop.set()
        self.cancel_action("выход из приложения")
        if self.login.running():
            kill_group(self.login.proc, 1.0)

    # ---------- IP ----------

    def get_ip(self, force: bool = False) -> dict:
        c = self._ip
        if not force and c["data"] is not None and time.monotonic() - c["ts"] < IP_CACHE_SECONDS:
            return c["data"]
        data = fetch_ip()
        c.update(ts=time.monotonic(), data=data)
        return data

    # ---------- обновление AdGuard VPN CLI ----------

    def check_update(self, force: bool = False) -> dict:
        c = self._update
        if not force and c["data"] is not None and time.monotonic() - c["ts"] < UPDATE_CACHE_SECONDS:
            return c["data"]
        data = {"installed": "", "latest": "", "update_available": False, "error": None}
        if find_cli():
            r = self.cli.once(["--version"], STATUS_TIMEOUT)
            v = version_tuple(r["output"]) if not r["timeout"] else None
            data["installed"] = ".".join(map(str, v)) if v else ""
        try:
            fake = os.environ.get("ADGUARD_VPN_DESKTOP_FAKE_LATEST")       # только для тестов
            rel = {"tag_name": fake} if fake else http_json(GITHUB_LATEST, 15)
            lv = version_tuple(rel.get("tag_name", ""))
            data["latest"] = ".".join(map(str, lv)) if lv else ""
        except Exception as e:
            data["error"] = f"GitHub: {e}"[:200]
        iv, lv = version_tuple(data["installed"]), version_tuple(data["latest"])
        data["update_available"] = bool(iv and lv and lv > iv)
        if data["update_available"]:
            self.events.add("info", f"Доступно обновление AdGuard {data['latest']}", f"установлено: {data['installed']}")
        elif data["error"]:
            self.events.add("warn", "Проверка обновления: нет связи с GitHub", data["error"])
        elif force:
            self.events.add("info", f"AdGuard {data['installed'] or '?'} — последняя версия", f"GitHub: {data['latest']}")
        c.update(ts=time.monotonic(), data=data)
        return data

    def run_update(self) -> dict:
        """Официальное обновление `adguardvpn-cli update -y -v` (до 10 мин., под общим замком)."""
        self.sudo_state()
        self.events.add("info", "Обновление AdGuard запущено", "adguardvpn-cli update -y -v")
        if not self.lock.acquire(LOCK_WAIT):
            self.events.add("error", "Ошибка: AdGuard занят (обновление)", "")
            return {"ok": False, "message": "AdGuard занят другой программой"}
        try:
            r = self.cli.run(["update", "-y", "-v"], UPDATE_TIMEOUT,
                             out_path=os.path.join(state_dir(), "update.log"), track=False)
        finally:
            self.lock.release()
        body = r["output"]
        ok = r["code"] == 0 and not re.search(r"\b(error|failed)\b", body, re.IGNORECASE)
        self._update["ts"] = 0.0
        self.events.add("ok" if ok else "error", "AdGuard обновлён" if ok else explain_error(body) + " (обновление)",
                        f"код: {r['code']}\n{body}")
        return {"ok": ok, "message": "Обновлено" if ok else "Ошибка обновления", "output": body[-1500:]}
